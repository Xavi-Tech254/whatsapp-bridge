const mongoose = require('mongoose');

const memberSchema = new mongoose.Schema({
  uniqueCode: { type: String, unique: true },
  realName: String,
  phone: { type: String, unique: true },
  dob: String,
  photo: String,
  homeLocation: { lat: Number, lng: Number, address: String, village: String },
  currentLocation: { lat: Number, lng: Number, address: String, updatedAt: Date },
  groups: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Group' }],
  status: { type: String, enum: ['pending','active','banned','left'], default: 'pending' },
  joinedAt: { type: Date, default: Date.now },
  warnings: { type: Number, default: 0 },
  isMuted: { type: Boolean, default: false }
});

const groupSchema = new mongoose.Schema({
  name: String,
  groupJid: { type: String, unique: true },
  type: { type: String, enum: ['general','fundraising','chama'] },
  language: { type: String, default: 'en' },
  rules: String,
  codePrefix: { type: String, default: 'ALG' },
  admins: [{
    phone: String, name: String,
    position: { type: String, enum: ['chairperson','treasurer','secretary','admin'] },
    panelPassword: String
  }],
  members: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Member' }],
  target: { type: Number, default: 0 },
  totalContributions: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
  isActive: { type: Boolean, default: true }
});

const contributionSchema = new mongoose.Schema({
  member: { type: mongoose.Schema.Types.ObjectId, ref: 'Member' },
  group: { type: mongoose.Schema.Types.ObjectId, ref: 'Group' },
  amount: Number,
  mpesaCode: String,
  verifiedBy: String,
  date: { type: Date, default: Date.now },
  month: String,
  status: { type: String, enum: ['pending','verified'], default: 'pending' }
});

const joinRequestSchema = new mongoose.Schema({
  phone: String,
  group: { type: mongoose.Schema.Types.ObjectId, ref: 'Group' },
  formData: {
    realName: String, dob: String, photo: String,
    homeLocation: Object, currentLocation: Object, acceptedRules: Boolean
  },
  status: { type: String, enum: ['pending','approved','rejected'], default: 'pending' },
  submittedAt: { type: Date, default: Date.now }
});

const pollSchema = new mongoose.Schema({
  group: { type: mongoose.Schema.Types.ObjectId, ref: 'Group' },
  question: String,
  options: [String],
  votes: [{ phone: String, option: String }],
  createdBy: String,
  endsAt: Date,
  status: { type: String, enum: ['active','closed'], default: 'active' },
  winner: String,
  createdAt: { type: Date, default: Date.now }
});

const meetingSchema = new mongoose.Schema({
  group: { type: mongoose.Schema.Types.ObjectId, ref: 'Group' },
  title: String, reason: String, agenda: String,
  meetLink: String, scheduledAt: Date, createdBy: String,
  createdAt: { type: Date, default: Date.now }
});

const suggestionSchema = new mongoose.Schema({
  member: { type: mongoose.Schema.Types.ObjectId, ref: 'Member' },
  group: { type: mongoose.Schema.Types.ObjectId, ref: 'Group' },
  message: String,
  status: { type: String, enum: ['pending','reviewed'], default: 'pending' },
  createdAt: { type: Date, default: Date.now }
});

module.exports = {
  Member: mongoose.model('Member', memberSchema),
  Group: mongoose.model('Group', groupSchema),
  Contribution: mongoose.model('Contribution', contributionSchema),
  JoinRequest: mongoose.model('JoinRequest', joinRequestSchema),
  Poll: mongoose.model('Poll', pollSchema),
  Meeting: mongoose.model('Meeting', meetingSchema),
  Suggestion: mongoose.model('Suggestion', suggestionSchema)
};
