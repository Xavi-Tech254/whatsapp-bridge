const { Member, Group } = require('../database/schema');

// Generate unique member code
async function generateUniqueCode(group) {
  const prefix = group.codePrefix || 'ALG';
  const count = group.members.length + 1;
  const code = `${prefix}-${String(count).padStart(3, '0')}`;
  return code;
}

// Get group from JID
async function getGroup(groupJid) {
  return await Group.findOne({ groupJid, isActive: true });
}

// Get member from phone
async function getMember(phone) {
  const clean = phone.replace(/[^0-9]/g, '').replace('@s.whatsapp.net', '');
  return await Member.findOne({ phone: clean, status: 'active' });
}

// Check if user is admin of group
function isAdmin(group, phone) {
  const clean = phone.replace(/[^0-9]/g, '').replace('@s.whatsapp.net', '');
  return group.admins.some(a => a.phone === clean);
}

// Check if supreme admin
function isSupreme(phone) {
  const clean = phone.replace(/[^0-9]/g, '').replace('@s.whatsapp.net', '');
  const supremes = (process.env.SUPREME_PHONES || '').split(',');
  return supremes.includes(clean);
}

// Format location as Google Maps link
function locationLink(lat, lng, label) {
  return `📍 ${label}\nhttps://maps.google.com/?q=${lat},${lng}`;
}

// Format date
function formatDate(date) {
  return new Date(date).toLocaleString('en-KE', { timeZone: 'Africa/Nairobi' });
}

// Send buttons message
async function sendButtons(sock, jid, text, buttons, footer = 'AlegoConnect') {
  try {
    await sock.sendMessage(jid, {
      text,
      footer,
      buttons: buttons.map((b, i) => ({
        buttonId: b.id || `btn_${i}`,
        buttonText: { displayText: b.text },
        type: 1
      })),
      headerType: 1
    });
  } catch (e) {
    // Fallback to text
    const btnText = buttons.map(b => `• ${b.text}`).join('\n');
    await sock.sendMessage(jid, { text: `${text}\n\n${btnText}` });
  }
}

// Send list message
async function sendList(sock, jid, text, sections, btnText = 'Select Option') {
  try {
    await sock.sendMessage(jid, {
      text,
      footer: 'AlegoConnect',
      title: 'Menu',
      buttonText: btnText,
      sections
    });
  } catch (e) {
    const items = sections.flatMap(s => s.rows.map(r => `• ${r.title}`)).join('\n');
    await sock.sendMessage(jid, { text: `${text}\n\n${items}` });
  }
}

module.exports = {
  generateUniqueCode, getGroup, getMember,
  isAdmin, isSupreme, locationLink, formatDate,
  sendButtons, sendList
};
