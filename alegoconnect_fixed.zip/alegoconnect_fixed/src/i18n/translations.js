const translations = {
  en: {
    welcome: '👋 Welcome to AlegoConnect!',
    menu: '📋 Main Menu',
    notMember: '❌ You are not a member of this group.',
    notAdmin: '❌ This command is for admins only.',
    contributed: '✅ Your contribution has been recorded.',
    joinRequest: '📝 Please fill the verification form to join.',
    approved: '✅ Your request has been approved! Welcome!',
    rejected: '❌ Your request has been rejected.',
  },
  sw: {
    welcome: '👋 Karibu AlegoConnect!',
    menu: '📋 Menyu Kuu',
    notMember: '❌ Wewe si mwanachama wa kikundi hiki.',
    notAdmin: '❌ Amri hii ni kwa wasimamizi tu.',
    contributed: '✅ Mchango wako umerekodiwa.',
    joinRequest: '📝 Tafadhali jaza fomu ya uthibitisho.',
    approved: '✅ Ombi lako limeidhinishwa! Karibu!',
    rejected: '❌ Ombi lako limekataliwa.',
  },
  luo: {
    welcome: '👋 Wasuol e AlegoConnect!',
    menu: '📋 Lach Marach',
    notMember: '❌ Ok in wuon joka grup ni.',
    notAdmin: '❌ Chik ni en mar jopuonjre kende.',
    contributed: '✅ Konyruok mari ocoroke.',
    joinRequest: '📝 Yieni fomu mar neno mondo ijoin.',
    approved: '✅ Koro ilandore! Wasuol!',
    rejected: '❌ Koro ok ilandore.',
  }
};

function t(lang, key) {
  return translations[lang]?.[key] || translations['en'][key] || key;
}

module.exports = { t, translations };
