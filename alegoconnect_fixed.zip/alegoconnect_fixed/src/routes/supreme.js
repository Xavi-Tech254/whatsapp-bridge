const router = require('express').Router();
const { Group, Member, Contribution, JoinRequest, Poll } = require('../database/schema');

// Auth middleware
function auth(req, res, next) {
  const pass = req.headers['x-supreme-password'] || req.body?.password;
  if (pass !== process.env.SUPREME_PASSWORD) {
    return res.status(401).json({ success: false, error: 'Unauthorized' });
  }
  next();
}

// Login
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  const emails = (process.env.SUPREME_EMAILS || '').split(',');
  if (emails.includes(email) && password === process.env.SUPREME_PASSWORD) {
    res.json({ success: true, token: process.env.SUPREME_PASSWORD });
  } else {
    res.json({ success: false, error: 'Invalid credentials' });
  }
});

// Get all groups
router.get('/groups', auth, async (req, res) => {
  const groups = await Group.find().populate('members');
  res.json({ success: true, groups });
});

// Create group — accepts inviteLink, bot auto-joins
router.post('/groups', auth, async (req, res) => {
  try {
    const { name, type, inviteLink, codePrefix } = req.body;

    if (!inviteLink || !inviteLink.includes('chat.whatsapp.com/')) {
      return res.json({ success: false, error: 'Invalid WhatsApp invite link. Must be https://chat.whatsapp.com/XXXXX' });
    }

    // Extract invite code from link
    const inviteCode = inviteLink.split('chat.whatsapp.com/')[1]?.split('?')[0]?.trim();
    if (!inviteCode) {
      return res.json({ success: false, error: 'Could not extract invite code from link' });
    }

    const { getSock } = require('../bot');
    const sock = getSock();
    if (!sock) {
      return res.json({ success: false, error: 'Bot is not connected. Please pair the bot first.' });
    }

    // Bot joins the group via invite link
    let groupJid;
    try {
      groupJid = await sock.groupAcceptInvite(inviteCode);
    } catch (joinErr) {
      return res.json({ success: false, error: `Bot failed to join group: ${joinErr.message}` });
    }

    // Check if group already registered
    const existing = await Group.findOne({ groupJid });
    if (existing) {
      return res.json({ success: false, error: 'This group is already registered in the system.' });
    }

    const group = new Group({ name, type, groupJid, codePrefix: codePrefix || 'ALG' });
    await group.save();

    res.json({ success: true, group });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

// Update group
router.put('/groups/:id', auth, async (req, res) => {
  try {
    const group = await Group.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, group });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

// Add admin to group
router.post('/groups/:id/admins', auth, async (req, res) => {
  try {
    const group = await Group.findById(req.params.id);
    group.admins.push(req.body);
    await group.save();
    res.json({ success: true, group });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

// Get all members
router.get('/members', auth, async (req, res) => {
  const members = await Member.find().populate('groups');
  res.json({ success: true, members });
});

// Give position to member
router.post('/members/:id/position', auth, async (req, res) => {
  try {
    const { groupId, position } = req.body;
    const group = await Group.findById(groupId);
    const member = await Member.findById(req.params.id);
    const admin = group.admins.find(a => a.phone === member.phone);
    if (admin) {
      admin.position = position;
    } else {
      group.admins.push({ phone: member.phone, name: member.realName, position });
    }
    await group.save();
    res.json({ success: true });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

// Get all contributions
router.get('/contributions', auth, async (req, res) => {
  const contributions = await Contribution.find().populate('member group');
  res.json({ success: true, contributions });
});

// Stats
router.get('/stats', auth, async (req, res) => {
  const members = await Member.countDocuments({ status: 'active' });
  const groups = await Group.countDocuments({ isActive: true });
  const contributions = await Contribution.aggregate([
    { $match: { status: 'verified' } },
    { $group: { _id: null, total: { $sum: '$amount' } } }
  ]);
  res.json({
    success: true,
    stats: {
      members,
      groups,
      totalContributions: contributions[0]?.total || 0
    }
  });
});

module.exports = router;
