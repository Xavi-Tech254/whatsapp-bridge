const router = require('express').Router();
const { Group, Member, Contribution, JoinRequest } = require('../database/schema');

// Auth middleware
async function auth(req, res, next) {
  const { groupId, password } = req.headers;
  const group = await Group.findById(groupId);
  if (!group) return res.status(404).json({ success: false, error: 'Group not found' });
  const admin = group.admins.find(a => a.panelPassword === password);
  if (!admin) return res.status(401).json({ success: false, error: 'Unauthorized' });
  req.group = group;
  req.admin = admin;
  next();
}

// Login
router.post('/login', async (req, res) => {
  try {
    const { groupId, password } = req.body;
    const group = await Group.findById(groupId);
    if (!group) return res.json({ success: false, error: 'Group not found' });
    const admin = group.admins.find(a => a.panelPassword === password);
    if (!admin) return res.json({ success: false, error: 'Invalid password' });
    res.json({ success: true, admin, group: { name: group.name, type: group.type } });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

// Get members
router.get('/members', auth, async (req, res) => {
  await Group.populate(req.group, { path: 'members' });
  res.json({ success: true, members: req.group.members });
});

// Get contributions
router.get('/contributions', auth, async (req, res) => {
  const contributions = await Contribution.find({ group: req.group._id }).populate('member');
  res.json({ success: true, contributions });
});

// Verify payment (admin pastes M-Pesa message)
router.post('/verify', auth, async (req, res) => {
  try {
    const { mpesaMessage } = req.body;
    // Parse M-Pesa message: "XYZ confirmed. KSh 500 sent to..."
    const codeMatch = mpesaMessage.match(/^([A-Z0-9]+)\s/);
    const amountMatch = mpesaMessage.match(/KSh\s?([\d,]+)/);
    const nameMatch = mpesaMessage.match(/received from\s+(.+?)\s+on/i) ||
      mpesaMessage.match(/sent to\s+(.+?)\s+on/i);

    if (!codeMatch || !amountMatch) {
      return res.json({ success: false, error: 'Could not parse M-Pesa message' });
    }

    const mpesaCode = codeMatch[1];
    const amount = parseInt(amountMatch[1].replace(',', ''));
    const senderName = nameMatch?.[1] || '';

    // Find member by name
    await Group.populate(req.group, { path: 'members' });
    const member = req.group.members.find(m =>
      m.realName.toLowerCase().includes(senderName.toLowerCase().split(' ')[0])
    );

    if (!member) {
      return res.json({ success: false, error: `Member not found for name: ${senderName}` });
    }

    // Check duplicate
    const existing = await Contribution.findOne({ mpesaCode });
    if (existing) return res.json({ success: false, error: 'M-Pesa code already used' });

    const contribution = new Contribution({
      member: member._id,
      group: req.group._id,
      amount,
      mpesaCode,
      verifiedBy: req.admin.name,
      month: new Date().toLocaleString('en-KE', { month: 'long', year: 'numeric' })
    });
    await contribution.save();

    req.group.totalContributions += amount;
    await req.group.save();

    res.json({ success: true, member: member.realName, amount, mpesaCode });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

// Get join requests
router.get('/requests', auth, async (req, res) => {
  const requests = await JoinRequest.find({ group: req.group._id, status: 'pending' });
  res.json({ success: true, requests });
});

// Approve/reject join request
router.post('/requests/:id', auth, async (req, res) => {
  try {
    const { action } = req.body;
    const request = await JoinRequest.findById(req.params.id);
    if (!request) return res.json({ success: false, error: 'Request not found' });

    request.status = action;
    await request.save();

    if (action === 'approved') {
      const { welcomeMember } = require('../handlers/messageHandler');
      const { getSock } = require('../bot');

      // Create or update member
      let member = await Member.findOne({ phone: request.phone });
      if (!member) {
        const uniqueCode = await require('../utils/helpers').generateUniqueCode(req.group);
        member = new Member({
          uniqueCode,
          phone: request.phone,
          realName: request.formData.realName,
          dob: request.formData.dob,
          photo: request.formData.photo,
          homeLocation: request.formData.homeLocation,
          currentLocation: request.formData.currentLocation,
          status: 'active',
          groups: [req.group._id]
        });
      } else {
        member.status = 'active';
        member.groups.push(req.group._id);
      }
      await member.save();

      req.group.members.push(member._id);
      await req.group.save();

      const sock = getSock();
      if (sock) await welcomeMember(sock, req.group, member);
    }

    res.json({ success: true });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

module.exports = router;
