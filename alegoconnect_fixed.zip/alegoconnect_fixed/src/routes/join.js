const router = require('express').Router();
const { Group, JoinRequest } = require('../database/schema');
const PDFDocument = require('pdfkit');
const path = require('path');
const fs = require('fs');

// Get group info for join form
router.get('/group/:id', async (req, res) => {
  try {
    const group = await Group.findById(req.params.id);
    if (!group) return res.json({ success: false, error: 'Group not found' });
    res.json({ success: true, group: { name: group.name, type: group.type, rules: group.rules } });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

// Submit join request
router.post('/submit', async (req, res) => {
  try {
    const { groupId, phone, realName, dob, photo, homeLocation, currentLocation, acceptedRules } = req.body;

    if (!realName || !dob || !acceptedRules) {
      return res.json({ success: false, error: 'Please fill all required fields' });
    }

    const group = await Group.findById(groupId);
    if (!group) return res.json({ success: false, error: 'Group not found' });

    // Check existing request
    const existing = await JoinRequest.findOne({ phone, group: groupId, status: 'pending' });
    if (existing) return res.json({ success: false, error: 'Request already submitted' });

    const request = new JoinRequest({
      phone,
      group: groupId,
      formData: { realName, dob, photo, homeLocation, currentLocation, acceptedRules }
    });
    await request.save();

    // Generate PDF and notify admins
    await generatePDF(request, group);

    // Notify admins via WhatsApp
    const { getSock } = require('../bot');
    const sock = getSock();
    if (sock) {
      for (const admin of group.admins) {
        const adminJid = `${admin.phone}@s.whatsapp.net`;
        await sock.sendMessage(adminJid, {
          text: `📋 *New Join Request*\n_${group.name}_\n\n` +
            `👤 Name: ${realName}\n📱 Phone: ${phone}\n🎂 DOB: ${dob}\n\n` +
            `📍 Home: ${homeLocation?.address || 'N/A'}\n` +
            `📍 Current: ${currentLocation?.address || 'N/A'}\n\n` +
            `_Review on your admin panel_`
        });
      }
    }

    res.json({ success: true, message: 'Request submitted! Awaiting admin approval.' });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

async function generatePDF(request, group) {
  try {
    const doc = new PDFDocument();
    const filename = `request_${request._id}.pdf`;
    const filepath = path.join(__dirname, '../../data', filename);
    fs.mkdirSync(path.dirname(filepath), { recursive: true });
    doc.pipe(fs.createWriteStream(filepath));

    doc.fontSize(20).text('AlegoConnect - Join Request', { align: 'center' });
    doc.moveDown();
    doc.fontSize(14).text(`Group: ${group.name}`);
    doc.text(`Type: ${group.type}`);
    doc.moveDown();
    doc.fontSize(12).text(`Full Name: ${request.formData.realName}`);
    doc.text(`Phone: ${request.phone}`);
    doc.text(`Date of Birth: ${request.formData.dob}`);
    doc.text(`Home Location: ${request.formData.homeLocation?.address || 'N/A'}`);
    doc.text(`Current Location: ${request.formData.currentLocation?.address || 'N/A'}`);
    doc.text(`Rules Accepted: Yes`);
    doc.text(`Submitted: ${new Date().toLocaleString('en-KE', { timeZone: 'Africa/Nairobi' })}`);
    doc.end();
  } catch (e) {
    console.error('PDF error:', e);
  }
}

module.exports = router;
