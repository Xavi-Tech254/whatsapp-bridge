const { Member, Group, Contribution } = require('../../database/schema');
const { isAdmin, isSupreme, formatDate, sendList } = require('../../utils/helpers');
const { t } = require('../../i18n/translations');

// .menu - Chama menu
async function menu(sock, msg, group, member, lang) {
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || jid;
  const admin = isAdmin(group, sender) || isSupreme(sender);

  if (admin) {
    await sendList(sock, jid,
      `🏦 *Chama Admin Menu*\n_${group.name}_`,
      [
        {
          title: '💰 Accounts',
          rows: [
            { title: '📊 All Accounts', rowId: 'cmd_account_all', description: 'View all member accounts' },
            { title: '✅ Verify Payment', rowId: 'cmd_verify', description: 'Verify M-Pesa payment' },
            { title: '⏰ Due Payments', rowId: 'cmd_due_all', description: 'View overdue members' },
            { title: '🔔 Remind All', rowId: 'cmd_remind', description: 'Remind unpaid members' },
            { title: '📋 Full Statement', rowId: 'cmd_statement_all', description: 'Full chama statement' },
          ]
        },
        {
          title: '⚙️ Management',
          rows: [
            { title: '🎯 Set Target', rowId: 'cmd_target_set', description: 'Set contribution target' },
            { title: '👥 Members', rowId: 'cmd_members', description: 'View all members' },
            { title: '📢 Announce', rowId: 'cmd_announce', description: 'Send announcement' },
          ]
        }
      ],
      '🏦 Admin Menu'
    );
  } else {
    await sendList(sock, jid,
      `🏦 *Chama Menu*\n_${group.name}_`,
      [
        {
          title: '🏦 My Account',
          rows: [
            { title: '💰 My Account', rowId: 'cmd_account', description: 'View your account balance' },
            { title: '📋 My Statement', rowId: 'cmd_statement', description: 'View full statement' },
            { title: '⏰ My Due', rowId: 'cmd_due', description: 'View upcoming payment deadline' },
            { title: '💳 My Contributions', rowId: 'cmd_contribution', description: 'View contributions' },
          ]
        },
        {
          title: '👥 Group',
          rows: [
            { title: '👥 Members', rowId: 'cmd_members', description: 'View all members' },
            { title: '📋 Rules', rowId: 'cmd_rules', description: 'View group rules' },
            { title: '💡 Suggest', rowId: 'cmd_suggest', description: 'Send private suggestion' },
          ]
        }
      ],
      '📋 Menu'
    );
  }
}

// .account - View own account
async function account(sock, msg, group, member, lang) {
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || jid;
  const senderPhone = sender.replace('@s.whatsapp.net', '');
  const admin = isAdmin(group, sender) || isSupreme(sender);

  if (admin) {
    // Admin: show all accounts
    await Group.populate(group, { path: 'members' });
    let text = `📊 *All Member Accounts*\n_${group.name}_\n`;
    text += `━━━━━━━━━━━━━━━\n\n`;

    for (const m of group.members) {
      const contributions = await Contribution.find({
        member: m._id, group: group._id, status: 'verified'
      });
      const total = contributions.reduce((sum, c) => sum + c.amount, 0);
      text += `🔑 ${m.uniqueCode} — ${m.realName}\n`;
      text += `💰 Balance: KSh ${total.toLocaleString()}\n\n`;
    }

    const adminJid = `${senderPhone}@s.whatsapp.net`;
    await sock.sendMessage(adminJid, { text });
    await sock.sendMessage(jid, { text: '✅ Account details sent to your inbox.' });
  } else {
    if (!member) return sock.sendMessage(jid, { text: t(lang, 'notMember') });

    const contributions = await Contribution.find({
      member: member._id, group: group._id, status: 'verified'
    });
    const total = contributions.reduce((sum, c) => sum + c.amount, 0);
    const target = group.target;
    const remaining = Math.max(0, target - total);

    let text = `🏦 *Your Account*\n_${group.name}_\n`;
    text += `━━━━━━━━━━━━━━━\n`;
    text += `🔑 Code: ${member.uniqueCode}\n`;
    text += `📛 Name: ${member.realName}\n`;
    text += `💰 Total Saved: KSh ${total.toLocaleString()}\n`;
    text += `🎯 Target: KSh ${target.toLocaleString()}\n`;
    text += `📊 Remaining: KSh ${remaining.toLocaleString()}\n`;
    text += `📅 Contributions: ${contributions.length}`;

    const memberJid = `${member.phone}@s.whatsapp.net`;
    await sock.sendMessage(memberJid, { text });
    await sock.sendMessage(jid, { text: '✅ Account details sent to your inbox.' });
  }
}

// .statement - Full transaction history
async function statement(sock, msg, group, member, lang) {
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || jid;
  const senderPhone = sender.replace('@s.whatsapp.net', '');
  const admin = isAdmin(group, sender) || isSupreme(sender);

  if (admin) {
    const contributions = await Contribution.find({ group: group._id, status: 'verified' })
      .populate('member').sort({ date: -1 });

    let text = `📋 *Full Chama Statement*\n_${group.name}_\n`;
    text += `Total: KSh ${group.totalContributions.toLocaleString()}\n`;
    text += `━━━━━━━━━━━━━━━\n\n`;

    for (const c of contributions) {
      text += `${c.member?.realName} (${c.member?.uniqueCode})\n`;
      text += `KSh ${c.amount.toLocaleString()} — ${formatDate(c.date)}\n`;
      text += `M-Pesa: ${c.mpesaCode}\n\n`;
    }

    const adminJid = `${senderPhone}@s.whatsapp.net`;
    await sock.sendMessage(adminJid, { text });
    await sock.sendMessage(jid, { text: '✅ Statement sent to your inbox.' });
  } else {
    if (!member) return sock.sendMessage(jid, { text: t(lang, 'notMember') });

    const contributions = await Contribution.find({
      member: member._id, group: group._id, status: 'verified'
    }).sort({ date: -1 });

    let text = `📋 *Your Statement*\n_${group.name}_\n`;
    text += `━━━━━━━━━━━━━━━\n\n`;

    for (const c of contributions) {
      text += `💰 KSh ${c.amount.toLocaleString()}\n`;
      text += `📅 ${formatDate(c.date)}\n`;
      text += `🔖 ${c.mpesaCode}\n\n`;
    }

    const memberJid = `${member.phone}@s.whatsapp.net`;
    await sock.sendMessage(memberJid, { text });
    await sock.sendMessage(jid, { text: '✅ Statement sent to your inbox.' });
  }
}

// .due - Payment deadline
async function due(sock, msg, group, member, lang) {
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || jid;
  const senderPhone = sender.replace('@s.whatsapp.net', '');
  const admin = isAdmin(group, sender) || isSupreme(sender);

  if (admin) {
    await Group.populate(group, { path: 'members' });
    const paidMembers = await Contribution.find({ group: group._id, status: 'verified' }).distinct('member');
    const unpaid = group.members.filter(m => !paidMembers.map(p => p.toString()).includes(m._id.toString()));

    let text = `⏰ *Overdue Members*\n_${group.name}_\n`;
    text += `━━━━━━━━━━━━━━━\n\n`;

    if (!unpaid.length) {
      text += '✅ All members have paid!';
    } else {
      for (const m of unpaid) {
        text += `🔑 ${m.uniqueCode} — ${m.realName}\n`;
        text += `📱 ${m.phone}\n\n`;
      }
    }

    const adminJid = `${senderPhone}@s.whatsapp.net`;
    await sock.sendMessage(adminJid, { text });
    await sock.sendMessage(jid, { text: '✅ Due list sent to your inbox.' });
  } else {
    if (!member) return sock.sendMessage(jid, { text: t(lang, 'notMember') });

    const contributions = await Contribution.find({
      member: member._id, group: group._id, status: 'verified'
    });
    const total = contributions.reduce((sum, c) => sum + c.amount, 0);
    const remaining = Math.max(0, group.target - total);

    const memberJid = `${member.phone}@s.whatsapp.net`;
    await sock.sendMessage(memberJid, {
      text: `⏰ *Your Payment Status*\n_${group.name}_\n\n` +
        `💰 Paid: KSh ${total.toLocaleString()}\n` +
        `📊 Remaining: KSh ${remaining.toLocaleString()}\n` +
        `🎯 Target: KSh ${group.target.toLocaleString()}\n\n` +
        `${remaining === 0 ? '✅ You are fully paid!' : '⚠️ Please complete your contribution.'}`
    });
    await sock.sendMessage(jid, { text: '✅ Due details sent to your inbox.' });
  }
}

module.exports = { menu, account, statement, due };
