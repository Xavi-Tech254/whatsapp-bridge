const { Member, Group, Poll, Meeting, Suggestion } = require('../../database/schema');
const { getGroup, getMember, isAdmin, isSupreme, locationLink, formatDate, sendButtons, sendList } = require('../../utils/helpers');
const { t } = require('../../i18n/translations');

// .menu - Interactive menu with buttons
async function menu(sock, msg, group, member, lang) {
  const jid = msg.key.remoteJid;
  const admin = isAdmin(group, msg.key.participant || jid);

  if (admin || isSupreme(msg.key.participant || jid)) {
    // Admin menu
    await sendList(sock, jid,
      `🌟 *AlegoConnect - Admin Menu*\n_${group.name}_`,
      [
        {
          title: '👥 Member Management',
          rows: [
            { title: '👥 Members List', rowId: 'cmd_members', description: 'View all members' },
            { title: '⚠️ Warn Member', rowId: 'cmd_warn', description: 'Warn a member' },
            { title: '🔇 Mute Member', rowId: 'cmd_mute', description: 'Mute a member' },
            { title: '🚫 Kick Member', rowId: 'cmd_kick', description: 'Remove a member' },
            { title: '🔨 Ban Member', rowId: 'cmd_ban', description: 'Ban a member permanently' },
          ]
        },
        {
          title: '📢 Communication',
          rows: [
            { title: '📢 Announce', rowId: 'cmd_announce', description: 'Send announcement' },
            { title: '📊 Create Poll', rowId: 'cmd_poll_create', description: 'Create a poll' },
            { title: '📅 Schedule Meeting', rowId: 'cmd_meeting_create', description: 'Schedule Google Meet' },
          ]
        },
        {
          title: '⚙️ Settings',
          rows: [
            { title: '👑 Manage Positions', rowId: 'cmd_position', description: 'Give/remove positions' },
            { title: '📋 Set Rules', rowId: 'cmd_rules_set', description: 'Update group rules' },
          ]
        }
      ],
      '👑 Admin Menu'
    );
  } else {
    // Member menu
    await sendList(sock, jid,
      `🌟 *AlegoConnect*\n_${group.name}_`,
      [
        {
          title: '👤 My Profile',
          rows: [
            { title: '👤 My Profile', rowId: 'cmd_profile', description: 'View your profile' },
            { title: '🔑 My Code', rowId: 'cmd_mycode', description: 'View your unique code' },
            { title: '📍 Update Location', rowId: 'cmd_location', description: 'Update current location' },
          ]
        },
        {
          title: '👥 Group',
          rows: [
            { title: '👥 Members', rowId: 'cmd_members', description: 'View all members' },
            { title: '📋 Rules', rowId: 'cmd_rules', description: 'View group rules' },
            { title: '📊 Active Polls', rowId: 'cmd_polls', description: 'View and vote on polls' },
            { title: '📅 Meetings', rowId: 'cmd_meetings', description: 'View scheduled meetings' },
          ]
        },
        {
          title: '💬 Communication',
          rows: [
            { title: '💡 Suggest', rowId: 'cmd_suggest', description: 'Send private suggestion to admins' },
            { title: '🤖 Bot Status', rowId: 'cmd_ping', description: 'Check bot status' },
          ]
        }
      ],
      '📋 Menu'
    );
  }
}

// .members - Show member list
async function members(sock, msg, group, member, lang) {
  const jid = msg.key.remoteJid;
  await Group.populate(group, { path: 'members' });

  if (!group.members.length) {
    return sock.sendMessage(jid, { text: '👥 No members yet.' });
  }

  let text = `👥 *${group.name} Members*\n`;
  text += `Total: ${group.members.length}\n`;
  text += `━━━━━━━━━━━━━━━\n\n`;

  for (const m of group.members) {
    text += `🔑 *${m.uniqueCode}* — ${m.realName}\n`;
    text += `📅 Joined: ${formatDate(m.joinedAt)}\n`;
    if (m.homeLocation?.address) {
      text += `🏠 ${locationLink(m.homeLocation.lat, m.homeLocation.lng, 'Home')}\n`;
    }
    if (m.currentLocation?.address) {
      text += `📍 ${locationLink(m.currentLocation.lat, m.currentLocation.lng, 'Current')}\n`;
    }
    text += `\n`;
  }

  await sock.sendMessage(jid, { text });
}

// .profile - Show own profile
async function profile(sock, msg, group, member, lang) {
  const jid = msg.key.remoteJid;
  if (!member) return sock.sendMessage(jid, { text: t(lang, 'notMember') });

  let text = `👤 *Your Profile*\n`;
  text += `━━━━━━━━━━━━━━━\n`;
  text += `🔑 Code: *${member.uniqueCode}*\n`;
  text += `📛 Name: ${member.realName}\n`;
  text += `📱 Phone: ${member.phone}\n`;
  text += `📅 Joined: ${formatDate(member.joinedAt)}\n`;
  text += `⚠️ Warnings: ${member.warnings}\n`;
  if (member.homeLocation?.address) {
    text += `\n🏠 *Home Location*\n${locationLink(member.homeLocation.lat, member.homeLocation.lng, member.homeLocation.village || 'Home')}\n`;
  }
  if (member.currentLocation?.address) {
    text += `\n📍 *Current Location*\n${locationLink(member.currentLocation.lat, member.currentLocation.lng, 'Current Location')}\n`;
  }

  await sock.sendMessage(jid, { text });
}

// .mycode
async function mycode(sock, msg, group, member, lang) {
  const jid = msg.key.remoteJid;
  if (!member) return sock.sendMessage(jid, { text: t(lang, 'notMember') });
  await sock.sendMessage(jid, {
    text: `🔑 *Your Unique Code*\n\n*${member.uniqueCode}*\n\n_This code identifies you in AlegoConnect_`
  });
}

// .rules
async function rules(sock, msg, group, member, lang) {
  const jid = msg.key.remoteJid;
  const text = group.rules || '📋 No rules set for this group yet.';
  await sock.sendMessage(jid, { text: `📋 *${group.name} Rules*\n\n${text}` });
}

// .ping
async function ping(sock, msg, group, member, lang) {
  const jid = msg.key.remoteJid;
  const start = Date.now();
  await sock.sendMessage(jid, { text: '🏓 Pong!' });
  const end = Date.now();
  await sock.sendMessage(jid, {
    text: `⚡ *AlegoConnect Status*\n\n🟢 Bot: Online\n⏱️ Latency: ${end - start}ms\n🌐 Group: ${group.name}`
  });
}

// .suggest - Private suggestion to admins
async function suggest(sock, msg, group, member, lang, args) {
  const jid = msg.key.remoteJid;
  if (!member) return sock.sendMessage(jid, { text: t(lang, 'notMember') });
  if (!args.length) return sock.sendMessage(jid, { text: '💡 Usage: .suggest <your message>' });

  const suggestion = new Suggestion({
    member: member._id,
    group: group._id,
    message: args.join(' ')
  });
  await suggestion.save();

  // Notify admins privately
  for (const admin of group.admins) {
    const adminJid = `${admin.phone}@s.whatsapp.net`;
    await sock.sendMessage(adminJid, {
      text: `💡 *New Suggestion*\n_${group.name}_\n\nFrom: Anonymous Member\nMessage: ${args.join(' ')}\n\n_Reply via panel_`
    });
  }

  // Confirm to member privately
  const senderJid = (msg.key.participant || jid).replace('@s.whatsapp.net', '') + '@s.whatsapp.net';
  await sock.sendMessage(senderJid, {
    text: `✅ Your suggestion has been sent to admins anonymously.`
  });
}

// .polls - View active polls
async function polls(sock, msg, group, member, lang) {
  const jid = msg.key.remoteJid;
  const activePolls = await Poll.find({ group: group._id, status: 'active' });

  if (!activePolls.length) {
    return sock.sendMessage(jid, { text: '📊 No active polls at the moment.' });
  }

  for (const poll of activePolls) {
    let text = `📊 *Poll*\n${poll.question}\n\n`;
    text += `Options:\n`;
    poll.options.forEach((opt, i) => {
      const votes = poll.votes.filter(v => v.option === opt).length;
      text += `${i + 1}. ${opt} (${votes} votes)\n`;
    });
    text += `\nEnds: ${formatDate(poll.endsAt)}\n`;
    text += `_Reply with .vote ${poll._id} <option number> to vote_`;

    await sock.sendMessage(jid, { text });
  }
}

// .vote
async function vote(sock, msg, group, member, lang, args) {
  const jid = msg.key.remoteJid;
  if (!member) return sock.sendMessage(jid, { text: t(lang, 'notMember') });
  if (args.length < 2) return sock.sendMessage(jid, { text: '🗳️ Usage: .vote <pollId> <option number>' });

  const poll = await Poll.findById(args[0]);
  if (!poll || poll.status !== 'active') return sock.sendMessage(jid, { text: '❌ Poll not found or already closed.' });

  const optionIndex = parseInt(args[1]) - 1;
  if (optionIndex < 0 || optionIndex >= poll.options.length) {
    return sock.sendMessage(jid, { text: '❌ Invalid option number.' });
  }

  // Check already voted
  const alreadyVoted = poll.votes.find(v => v.phone === member.phone);
  if (alreadyVoted) return sock.sendMessage(jid, { text: '❌ You have already voted.' });

  poll.votes.push({ phone: member.phone, option: poll.options[optionIndex] });
  await poll.save();

  const senderJid = (msg.key.participant || jid).replace('@s.whatsapp.net', '') + '@s.whatsapp.net';
  await sock.sendMessage(senderJid, {
    text: `✅ Vote recorded anonymously!\nYou voted for: ${poll.options[optionIndex]}`
  });
}

// .meetings
async function meetings(sock, msg, group, member, lang) {
  const jid = msg.key.remoteJid;
  const upcoming = await Meeting.find({
    group: group._id,
    scheduledAt: { $gte: new Date() }
  }).sort({ scheduledAt: 1 });

  if (!upcoming.length) {
    return sock.sendMessage(jid, { text: '📅 No upcoming meetings.' });
  }

  let text = `📅 *Upcoming Meetings*\n_${group.name}_\n\n`;
  for (const m of upcoming) {
    text += `📌 *${m.title}*\n`;
    text += `📋 Reason: ${m.reason}\n`;
    text += `📝 Agenda: ${m.agenda}\n`;
    text += `🕐 When: ${formatDate(m.scheduledAt)}\n`;
    text += `🔗 ${m.meetLink}\n\n`;
  }

  await sock.sendMessage(jid, { text });
}

// ADMIN COMMANDS
async function announce(sock, msg, group, member, lang, args) {
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || jid;
  if (!isAdmin(group, sender) && !isSupreme(sender)) {
    return sock.sendMessage(jid, { text: t(lang, 'notAdmin') });
  }
  if (!args.length) return sock.sendMessage(jid, { text: '📢 Usage: .announce <message>' });

  await sock.sendMessage(jid, {
    text: `📢 *ANNOUNCEMENT*\n_${group.name}_\n\n${args.join(' ')}\n\n— Admin`
  });
}

async function warn(sock, msg, group, member, lang, args) {
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || jid;
  if (!isAdmin(group, sender) && !isSupreme(sender)) {
    return sock.sendMessage(jid, { text: t(lang, 'notAdmin') });
  }

  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
  if (!mentioned) return sock.sendMessage(jid, { text: '⚠️ Usage: .warn @member <reason>' });

  const phone = mentioned.replace('@s.whatsapp.net', '');
  const target = await Member.findOne({ phone });
  if (!target) return sock.sendMessage(jid, { text: '❌ Member not found.' });

  target.warnings += 1;
  await target.save();

  await sock.sendMessage(jid, {
    text: `⚠️ *Warning Issued*\nMember: ${target.realName}\nWarnings: ${target.warnings}/3\nReason: ${args.join(' ') || 'Not specified'}`
  });

  if (target.warnings >= 3) {
    await sock.sendMessage(jid, { text: `🚨 ${target.realName} has reached 3 warnings!` });
  }
}

module.exports = { menu, members, profile, mycode, rules, ping, suggest, polls, vote, meetings, announce, warn };
