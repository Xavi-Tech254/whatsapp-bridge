const { Member, Group, Contribution } = require('../../database/schema');
const { getGroup, getMember, isAdmin, isSupreme, formatDate, sendList } = require('../../utils/helpers');
const { t } = require('../../i18n/translations');

// .menu - Fundraising menu
async function menu(sock, msg, group, member, lang) {
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || jid;
  const admin = isAdmin(group, sender) || isSupreme(sender);

  if (admin) {
    await sendList(sock, jid,
      `💰 *Fundraising Admin Menu*\n_${group.name}_`,
      [
        {
          title: '💰 Contributions',
          rows: [
            { title: '📋 Full List', rowId: 'cmd_contribution_list', description: 'View all contributions' },
            { title: '✅ Verify Payment', rowId: 'cmd_verify', description: 'Verify M-Pesa payment' },
            { title: '🎯 Set Target', rowId: 'cmd_target_set', description: 'Set fundraising target' },
            { title: '🔔 Remind All', rowId: 'cmd_remind', description: 'Remind unpaid members' },
          ]
        },
        {
          title: '👥 Members',
          rows: [
            { title: '👥 Members List', rowId: 'cmd_members', description: 'View all members' },
            { title: '📢 Announce', rowId: 'cmd_announce', description: 'Send announcement' },
          ]
        }
      ],
      '💰 Admin Menu'
    );
  } else {
    await sendList(sock, jid,
      `💰 *Fundraising Menu*\n_${group.name}_`,
      [
        {
          title: '💰 My Contributions',
          rows: [
            { title: '💳 My Contribution', rowId: 'cmd_contribution', description: 'View your contributions' },
            { title: '🎯 Target', rowId: 'cmd_target', description: 'View fundraising target' },
            { title: '💰 Total Raised', rowId: 'cmd_total', description: 'View total raised' },
          ]
        },
        {
          title: '👥 Group',
          rows: [
            { title: '👥 Members', rowId: 'cmd_members', description: 'View all members' },
            { title: '📋 Rules', rowId: 'cmd_rules', description: 'View group rules' },
            { title: '💡 Suggest', rowId: 'cmd_suggest', description: 'Send private suggestion' },
          ]
        }
      ],
      '📋 Menu'
    );
  }
}

// .contribute - Member sees own, Admin sees all
async function contribute(sock, msg, group, member, lang) {
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || jid;
  const senderPhone = sender.replace('@s.whatsapp.net', '');
  const admin = isAdmin(group, sender) || isSupreme(sender);

  if (admin) {
    // Admin: send full list to group
    const contributions = await Contribution.find({ group: group._id, status: 'verified' })
      .populate('member');

    let text = `📋 *Full Contribution List*\n_${group.name}_\n`;
    text += `━━━━━━━━━━━━━━━\n`;
    text += `Total: KSh ${group.totalContributions.toLocaleString()}\n\n`;

    for (const c of contributions) {
      text += `🔑 ${c.member?.uniqueCode} — ${c.member?.realName}\n`;
      text += `💰 KSh ${c.amount.toLocaleString()} | ${formatDate(c.date)}\n\n`;
    }

    await sock.sendMessage(jid, { text });

    // Also send to admin inbox
    const adminJid = `${senderPhone}@s.whatsapp.net`;
    await sock.sendMessage(adminJid, { text });

  } else {
    // Member: send to private inbox only
    if (!member) return sock.sendMessage(jid, { text: t(lang, 'notMember') });

    const contributions = await Contribution.find({
      member: member._id,
      group: group._id,
      status: 'verified'
    });

    const total = contributions.reduce((sum, c) => sum + c.amount, 0);

    let text = `💳 *Your Contributions*\n_${group.name}_\n`;
    text += `━━━━━━━━━━━━━━━\n`;
    text += `🔑 Code: ${member.uniqueCode}\n`;
    text += `💰 Total: KSh ${total.toLocaleString()}\n\n`;

    for (const c of contributions) {
      text += `• KSh ${c.amount.toLocaleString()} — ${formatDate(c.date)}\n`;
      text += `  Code: ${c.mpesaCode}\n`;
    }

    // Send to private inbox
    const memberJid = `${member.phone}@s.whatsapp.net`;
    await sock.sendMessage(memberJid, { text });
    await sock.sendMessage(jid, { text: '✅ Contribution details sent to your inbox.' });
  }
}

// .target - View fundraising target
async function target(sock, msg, group, member, lang) {
  const jid = msg.key.remoteJid;
  const raised = group.totalContributions;
  const goal = group.target;
  const percent = goal > 0 ? Math.round((raised / goal) * 100) : 0;
  const remaining = Math.max(0, goal - raised);

  const bar = '█'.repeat(Math.floor(percent / 10)) + '░'.repeat(10 - Math.floor(percent / 10));

  await sock.sendMessage(jid, {
    text: `🎯 *Fundraising Target*\n_${group.name}_\n\n` +
      `[${bar}] ${percent}%\n\n` +
      `💰 Raised: KSh ${raised.toLocaleString()}\n` +
      `🎯 Target: KSh ${goal.toLocaleString()}\n` +
      `📊 Remaining: KSh ${remaining.toLocaleString()}`
  });
}

// .total
async function total(sock, msg, group, member, lang) {
  const jid = msg.key.remoteJid;
  const contributions = await Contribution.find({ group: group._id, status: 'verified' })
    .populate('member');
  const count = contributions.length;

  await sock.sendMessage(jid, {
    text: `💰 *Total Raised*\n_${group.name}_\n\n` +
      `💵 Amount: KSh ${group.totalContributions.toLocaleString()}\n` +
      `👥 Contributors: ${count}\n` +
      `🎯 Target: KSh ${group.target.toLocaleString()}`
  });
}

// Admin: .settarget
async function settarget(sock, msg, group, member, lang, args) {
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || jid;
  if (!isAdmin(group, sender) && !isSupreme(sender)) {
    return sock.sendMessage(jid, { text: t(lang, 'notAdmin') });
  }
  if (!args[0] || isNaN(args[0])) {
    return sock.sendMessage(jid, { text: '🎯 Usage: .settarget <amount>' });
  }

  group.target = parseInt(args[0]);
  await group.save();

  await sock.sendMessage(jid, {
    text: `✅ Fundraising target set to KSh ${parseInt(args[0]).toLocaleString()}`
  });
}

// Admin: .remind - Remind unpaid members
async function remind(sock, msg, group, member, lang) {
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || jid;
  if (!isAdmin(group, sender) && !isSupreme(sender)) {
    return sock.sendMessage(jid, { text: t(lang, 'notAdmin') });
  }

  await Group.populate(group, { path: 'members' });
  const paidMembers = await Contribution.find({ group: group._id, status: 'verified' }).distinct('member');
  const unpaid = group.members.filter(m => !paidMembers.includes(m._id.toString()));

  for (const m of unpaid) {
    const memberJid = `${m.phone}@s.whatsapp.net`;
    await sock.sendMessage(memberJid, {
      text: `🔔 *Reminder*\n_${group.name}_\n\nDear ${m.realName},\n\nYou have not contributed yet.\nTarget: KSh ${group.target.toLocaleString()}\n\nPlease contribute as soon as possible.\n\n_AlegoConnect_`
    });
  }

  await sock.sendMessage(jid, {
    text: `✅ Reminder sent to ${unpaid.length} member(s).`
  });
}

module.exports = { menu, contribute, target, total, settarget, remind };
