/**
 * MongoDB Auth State for Baileys
 * Persists WhatsApp session in MongoDB so re-pairing is never needed after redeploy.
 */
const mongoose = require('mongoose');
const { BufferJSON, initAuthCreds } = require('@whiskeysockets/baileys');

const authSchema = new mongoose.Schema({
  _id: String,
  value: Object,
});

const AuthDoc = mongoose.models.BaileysAuth || mongoose.model('BaileysAuth', authSchema);

async function MongoAuthState() {
  const writeData = async (data, id) => {
    await AuthDoc.findByIdAndUpdate(
      id,
      { value: JSON.parse(JSON.stringify(data, BufferJSON.replacer)) },
      { upsert: true }
    );
  };

  const readData = async (id) => {
    const doc = await AuthDoc.findById(id);
    if (!doc) return null;
    return JSON.parse(JSON.stringify(doc.value), BufferJSON.reviver);
  };

  const removeData = async (id) => {
    await AuthDoc.findByIdAndDelete(id);
  };

  const creds = (await readData('creds')) || initAuthCreds();

  return {
    state: {
      creds,
      keys: {
        get: async (type, ids) => {
          const data = {};
          await Promise.all(
            ids.map(async (id) => {
              const value = await readData(`${type}-${id}`);
              if (value) data[id] = value;
            })
          );
          return data;
        },
        set: async (data) => {
          const tasks = [];
          for (const category of Object.keys(data)) {
            for (const id of Object.keys(data[category])) {
              const value = data[category][id];
              const docId = `${category}-${id}`;
              if (value) {
                tasks.push(writeData(value, docId));
              } else {
                tasks.push(removeData(docId));
              }
            }
          }
          await Promise.all(tasks);
        },
      },
    },
    saveCreds: () => writeData(creds, 'creds'),
  };
}

module.exports = { MongoAuthState };
