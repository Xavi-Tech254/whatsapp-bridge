const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
} = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const pino = require('pino');
const { handleMessage, handleGroupEvent } = require('./handlers/messageHandler');
const { MongoAuthState } = require('./mongoAuthState');

let sock = null;
let io = null;

function setSocketIO(socketIO) { io = socketIO; }
function getSock() { return sock; }

async function startBot() {
  const { state, saveCreds } = await MongoAuthState();
  const { version } = await fetchLatestBaileysVersion();
  const logger = pino({ level: 'silent' });

  sock = makeWASocket({
    version,
    logger,
    printQRInTerminal: false,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger)
    },
    browser: ['AlegoConnect', 'Firefox', '1.0.0'],
    markOnlineOnConnect: true,
    generateHighQualityLinkPreview: true,
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr && io) {
      io.emit('qr', { qr });
    }

    if (connection === 'close') {
      const shouldReconnect = (lastDisconnect?.error instanceof Boom)
        ? lastDisconnect.error.output?.statusCode !== DisconnectReason.loggedOut
        : true;

      console.log('Connection closed. Reconnecting:', shouldReconnect);
      if (io) io.emit('disconnected');

      if (shouldReconnect) {
        setTimeout(startBot, 3000);
      }
    }

    if (connection === 'open') {
      console.log('✅ AlegoConnect Bot Connected!');
      if (io) io.emit('connected', { phone: sock.user?.id });
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const msg of messages) {
      await handleMessage(sock, msg);
    }
  });

  sock.ev.on('group-participants.update', async (event) => {
    await handleGroupEvent(sock, [event]);
  });

  return sock;
}

async function requestPairingCode(phone) {
  if (!sock) throw new Error('Bot not started');
  const clean = phone.replace(/[^0-9]/g, '');
  const code = await sock.requestPairingCode(clean);
  return code;
}

module.exports = { startBot, requestPairingCode, setSocketIO, getSock };
