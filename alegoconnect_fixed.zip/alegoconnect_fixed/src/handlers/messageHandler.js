const { Group, Member, JoinRequest } = require('../database/schema');
const { getGroup, getMember, isAdmin, isSupreme, generateUniqueCode, locationLink, formatDate } = require('../utils/helpers');
const { t } = require('../i18n/translations');
const generalCmds = require('../commands/general');
const fundraisingCmds = require('../commands/fundraising');
const chamaCmds = require('../commands/chama');
const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

const PREFIX = process.env.PREFIX || '.';

async function handleMessage(sock, msg) {
  try {
    if (!msg.message) return;
    if (msg.key.fromMe) return;

    const jid = msg.key.remoteJid;
    const isGroup = jid.endsWith('@g.us');
    const sender = msg.key.participant || jid;
    const senderPhone = sender.replace('@s.whatsapp.net', '');

    // Get message text
    const text = msg.message?.conversation ||
      msg.message?.extendedTextMessage?.text ||
      msg.message?.buttonsResponseMessage?.selectedButtonId ||
      msg.message?.listResponseMessage?.singleSelectReply?.selectedRowId || '';

    if (!text) return;

    // Handle button/list responses
    const isButtonResponse = text.startsWith('cmd_');

    // Get group if group message
    let group = null;
    if (isGroup) {
      group = await Group.findOne({ groupJid: jid, isActive: true });
      if (!group) return; // Bot not configured for this group
    }

    const lang = group?.language || 'en';
    const member = await Member.findOne({ phone: senderPhone, status: 'active' });

    // Handle button responses
    if (isButtonResponse) {
      return await handleButtonResponse(sock, msg, text, group, member, lang, sender);
    }

    if (!text.startsWith(PREFIX)) return;

    const [cmd, ...args] = text.slice(PREFIX.length).trim().split(' ');
    const command = cmd.toLowerCase();

    // Route commands based on group type
    if (isGroup && group) {
      await routeGroupCommand(sock, msg, command, args, group, member, lang, sender);
    } else {
      // Private message commands
      await handlePrivateCommand(sock, msg, command, args, senderPhone, lang);
    }

  } catch (e) {
    console.error('Message handler error:', e);
  }
}

async function handleButtonResponse(sock, msg, buttonId, group, member, lang, sender) {
  const jid = msg.key.remoteJid;
  const args = [];

  const cmdMap = {
    'cmd_members': 'members',
    'cmd_profile': 'profile',
    'cmd_mycode': 'mycode',
    'cmd_rules': 'rules',
    'cmd_ping': 'ping',
    'cmd_suggest': 'suggest',
    'cmd_polls': 'polls',
    'cmd_meetings': 'meetings',
    'cmd_contribution': 'contribute',
    'cmd_target': 'target',
    'cmd_total': 'total',
    'cmd_account': 'account',
    'cmd_statement': 'statement',
    'cmd_due': 'due',
  };

  const cmd = cmdMap[buttonId];
  if (cmd) {
    await routeGroupCommand(sock, msg, cmd, args, group, member, lang, sender);
  }
}

async function routeGroupCommand(sock, msg, command, args, group, member, lang, sender) {
  const jid = msg.key.remoteJid;
  const type = group.type;

  // Commands available in ALL groups
  const commonCommands = {
    'menu': async () => {
      if (type === 'general') await generalCmds.menu(sock, msg, group, member, lang);
      else if (type === 'fundraising') await fundraisingCmds.menu(sock, msg, group, member, lang);
      else if (type === 'chama') await chamaCmds.menu(sock, msg, group, member, lang);
    },
    'members': () => generalCmds.members(sock, msg, group, member, lang),
    'profile': () => generalCmds.profile(sock, msg, group, member, lang),
    'mycode': () => generalCmds.mycode(sock, msg, group, member, lang),
    'rules': () => generalCmds.rules(sock, msg, group, member, lang),
    'ping': () => generalCmds.ping(sock, msg, group, member, lang),
    'suggest': () => generalCmds.suggest(sock, msg, group, member, lang, args),
    'announce': () => generalCmds.announce(sock, msg, group, member, lang, args),
    'warn': () => generalCmds.warn(sock, msg, group, member, lang, args),
    'polls': () => generalCmds.polls(sock, msg, group, member, lang),
    'vote': () => generalCmds.vote(sock, msg, group, member, lang, args),
    'meetings': () => generalCmds.meetings(sock, msg, group, member, lang),
  };

  // Fundraising specific
  const fundraisingCommands = {
    'contribute': () => fundraisingCmds.contribute(sock, msg, group, member, lang),
    'target': () => fundraisingCmds.target(sock, msg, group, member, lang),
    'total': () => fundraisingCmds.total(sock, msg, group, member, lang),
    'settarget': () => fundraisingCmds.settarget(sock, msg, group, member, lang, args),
    'remind': () => fundraisingCmds.remind(sock, msg, group, member, lang),
  };

  // Chama specific
  const chamaCommands = {
    'account': () => chamaCmds.account(sock, msg, group, member, lang),
    'statement': () => chamaCmds.statement(sock, msg, group, member, lang),
    'due': () => chamaCmds.due(sock, msg, group, member, lang),
    'contribute': () => fundraisingCmds.contribute(sock, msg, group, member, lang),
    'remind': () => fundraisingCmds.remind(sock, msg, group, member, lang),
  };

  if (commonCommands[command]) {
    await commonCommands[command]();
  } else if (type === 'fundraising' && fundraisingCommands[command]) {
    await fundraisingCommands[command]();
  } else if (type === 'chama' && chamaCommands[command]) {
    await chamaCommands[command]();
  } else {
    // Unknown command
    await sock.sendMessage(jid, {
      text: `❌ Unknown command: ${PREFIX}${command}\n\nType ${PREFIX}menu to see available commands.`
    });
  }
}

async function handlePrivateCommand(sock, msg, command, args, senderPhone, lang) {
  const jid = msg.key.remoteJid;

  if (command === 'ping') {
    await sock.sendMessage(jid, { text: '🏓 Pong! AlegoConnect is online.' });
  }
}

// Handle group events
async function handleGroupEvent(sock, event) {
  try {
    for (const action of event) {
      const { id, participants, action: act } = action;
      const group = await Group.findOne({ groupJid: id, isActive: true });
      if (!group) continue;

      const lang = group.language || 'en';

      if (act === 'add') {
        for (const participant of participants) {
          const phone = participant.replace('@s.whatsapp.net', '');
          const member = await Member.findOne({ phone });

          if (!member || member.status !== 'active') {
            // Send verification link
            const formUrl = `${process.env.PANEL_URL}/join?group=${group._id}&phone=${phone}`;
            await sock.sendMessage(participant, {
              text: `👋 Welcome!\n\nYou have been added to *${group.name}*.\n\n` +
                `To complete your registration, please fill the verification form:\n\n` +
                `🔗 ${formUrl}\n\n` +
                `_You will be removed if you don't complete the form within 24 hours._`
            });
          }
        }
      }

      if (act === 'remove') {
        for (const participant of participants) {
          const phone = participant.replace('@s.whatsapp.net', '');
          const member = await Member.findOne({ phone });
          if (!member) continue;

          // Notify admins
          for (const admin of group.admins) {
            const adminJid = `${admin.phone}@s.whatsapp.net`;
            await sock.sendMessage(adminJid, {
              text: `⚠️ *Member Left*\n_${group.name}_\n\n` +
                `👤 ${member.realName}\n🔑 ${member.uniqueCode}\n📱 ${phone}\n\n` +
                `_Please check the panel for details._`
            });
          }

          member.status = 'left';
          await member.save();
        }
      }
    }
  } catch (e) {
    console.error('Group event error:', e);
  }
}

// Welcome approved member
async function welcomeMember(sock, group, member) {
  try {
    let text = `🎉 *Welcome to ${group.name}!*\n\n`;
    text += `👤 ${member.realName}\n`;
    text += `🔑 Code: *${member.uniqueCode}*\n`;
    text += `📅 Joined: ${formatDate(member.joinedAt)}\n`;

    if (member.homeLocation?.lat) {
      text += `\n🏠 *Home Location (Siaya/Alego)*\nhttps://maps.google.com/?q=${member.homeLocation.lat},${member.homeLocation.lng}\n`;
    }
    if (member.currentLocation?.lat) {
      text += `\n📍 *Current Location*\nhttps://maps.google.com/?q=${member.currentLocation.lat},${member.currentLocation.lng}\n`;
    }

    text += `\nType *.menu* to see all commands. Welcome aboard! 🔥`;

    await sock.sendMessage(group.groupJid, { text });

    // Send profile pic if available
    if (member.photo) {
      await sock.sendMessage(group.groupJid, {
        image: { url: member.photo },
        caption: `📸 ${member.realName} — ${member.uniqueCode}`
      });
    }
  } catch (e) {
    console.error('Welcome error:', e);
  }
}

module.exports = { handleMessage, handleGroupEvent, welcomeMember };
