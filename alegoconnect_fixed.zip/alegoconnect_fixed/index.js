require('dotenv').config();
const express = require('express');
const { createServer } = require('http');
const { Server } = require('socket.io');
const mongoose = require('mongoose');
const path = require('path');
const { startBot, requestPairingCode, setSocketIO } = require('./src/bot');

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: '*' } });

const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'panel/public')));

// Connect MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/alegoconnect')
  .then(() => console.log('✅ MongoDB Connected'))
  .catch(e => console.error('MongoDB Error:', e));

// Routes
app.use('/api/supreme', require('./src/routes/supreme'));
app.use('/api/group', require('./src/routes/group'));
app.use('/api/join', require('./src/routes/join'));

// Pairing
app.get('/api/pair', async (req, res) => {
  try {
    const { phone } = req.query;
    if (!phone) return res.json({ success: false, error: 'Phone required' });
    const code = await requestPairingCode(phone);
    res.json({ success: true, code });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

// Status
app.get('/api/status', (req, res) => {
  res.json({
    status: 'Online',
    uptime: Math.floor(process.uptime()) + 's',
    version: '1.0.0'
  });
});

// Serve panels
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'panel/public/index.html')));
app.get('/join', (req, res) => res.sendFile(path.join(__dirname, 'panel/public/join.html')));
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'panel/supreme/public/index.html')));
app.get('/panel', (req, res) => res.sendFile(path.join(__dirname, 'panel/group/public/index.html')));

// Socket.IO
io.on('connection', (socket) => {
  console.log('Panel connected');
  socket.on('disconnect', () => console.log('Panel disconnected'));
});

setSocketIO(io);

// Start
httpServer.listen(PORT, async () => {
  console.log(`🌐 AlegoConnect Panel: http://localhost:${PORT}`);
  await startBot();
});
