# AlegoConnect - Siaya Alego Youth WhatsApp System

## Setup

1. Copy `.env.example` to `.env` and fill in your values
2. Run `npm install`
3. Run `node index.js`

## First Deployment — Bot Pairing (One Time Only)

1. Deploy to Railway (or any server)
2. Open your app URL (e.g. https://alegoconnect.up.railway.app)
3. Click **"🚀 Join Now"** on the homepage
4. Enter the bot WhatsApp number (e.g. 254712345678)
5. Solve the captcha, click **GET PAIRING CODE**
6. On WhatsApp → **Linked Devices** → **Link with phone number** → Enter code
7. ✅ Bot is now connected

> **Session is saved in MongoDB** — no re-pairing needed after redeploys.

## Adding Groups (Supreme Admin)

1. Go to `/admin` → Supreme Panel → Login
2. Under **Groups** tab → Add New Group
3. Paste the **WhatsApp invite link** (e.g. `https://chat.whatsapp.com/XXXXX`)
4. Click **Add Group** — the bot will auto-join and save the group instantly
5. Make the bot an **Admin** in the WhatsApp group

## Panels
- Public / Pairing: `http://localhost:3000`
- Supreme Admin: `http://localhost:3000/admin`
- Group Admin: `http://localhost:3000/panel`
- Join Form: `http://localhost:3000/join?group=GROUP_ID&phone=PHONE`

## Supreme Login
- Email: xaviclinton673@gmail.com or xavitech8@gmail.com
- Password: set in .env as SUPREME_PASSWORD

## Commands
### All Groups
- `.menu` - Interactive menu
- `.members` - Member list
- `.profile` - Your profile
- `.mycode` - Your unique code
- `.rules` - Group rules
- `.suggest` - Private suggestion to admins
- `.polls` - Active polls
- `.vote` - Vote on poll
- `.meetings` - Upcoming meetings
- `.ping` - Bot status

### Fundraising Group
- `.contribute` - Your contributions (member) / Full list (admin)
- `.target` - Fundraising target
- `.total` - Total raised
- `.settarget` - Set target (admin)
- `.remind` - Remind unpaid members (admin)

### Chama Group
- `.account` - Your account balance
- `.statement` - Full transaction history
- `.due` - Payment status
