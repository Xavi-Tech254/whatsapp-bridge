# 🤖 XaviBot — Multipurpose WhatsApp Bot

> 200+ commands | Web Panel | Multi-session | SQLite | Node.js

---

## 🚀 Quick Start

### 1. Install & Setup
```bash
git clone <your-repo>
cd xavibot
bash setup.sh
```

### 2. Configure .env
```env
OWNER_NUMBER=2348100000000   # Your WhatsApp number
BOT_PREFIX=.                  # Command prefix
PANEL_PORT=3000
GEMINI_API_KEY=               # For AI commands (optional)
WEATHER_API_KEY=              # For weather (optional)
```

### 3. Start the bot
```bash
npm start
```

### 4. Open Panel
Visit **http://localhost:3000**, enter a number → get pairing code → bot is live!

---

## 🐳 Deploy with Docker
```bash
docker build -t xavibot .
docker run -d -p 3000:3000 --env-file .env -v $(pwd)/sessions:/app/sessions -v $(pwd)/data:/app/data xavibot
```

## ☁️ Deploy on Railway / Render / VPS
1. Push code to GitHub
2. Connect repo to Railway/Render
3. Add environment variables
4. Deploy — panel auto-starts on assigned port

---

## 📋 Command List (200+)

### 🧠 AI (16+)
`.ai` `.gpt` `.imagine` `.summarize` `.rewrite` `.grammar` `.translate`
`.essay` `.story` `.poem` `.recipe` `.advice` `.caption` `.roast` `.compliment` `.motivation`

### 🎨 Media (12+)
`.sticker` `.toimg` `.attp` `.ytmp3` `.ytmp4` `.youtube` `.tiktok`
`.instagram` `.spotify` `.lyrics` `.removebg` `.emojimix`

### 👥 Group (30+)
`.kick` `.add` `.promote` `.demote` `.mute` `.unmute` `.lock` `.unlock`
`.welcome` `.goodbye` `.antilink` `.antispam` `.warn` `.warnings` `.resetwarn`
`.ban` `.unban` `.tagall` `.hidetag` `.note` `.getnote` `.notes` `.delnote`
`.poll` `.vote` `.pollresults` `.endpoll` `.setname` `.setdesc` `.invitelink`
`.revokelink` `.admins` `.members`

### 🎉 Fun (20+)
`.8ball` `.roll` `.flip` `.rps` `.truth` `.dare` `.wyr` `.ship` `.random`
`.daily` `.work` `.crime` `.balance` `.deposit` `.withdraw` `.leaderboard` `.give`
`.marry` `.divorce` `.spouse` `.level`

### 🛠️ Utility (30+)
`.help` `.ping` `.uptime` `.calc` `.weather` `.currency` `.time` `.qr`
`.profile` `.whois` `.info` `.reminder` `.myreminders` `.todo` `.afk`
`.shorturl` `.define` `.synonym` `.antonym` `.fact` `.trivia` `.quote`
`.horoscope` `.news` `.joke` `.riddle` `.answer` `.translate`

### 👑 Owner (12+)
`.broadcast` `.setpremium` `.removepremium` `.givecoins` `.botstats`
`.listgroups` `.restart` `.setprefix` `.joingroup` `.leavegroup`

---

## 🏗️ Project Structure
```
xavibot/
├── index.js              # Entry point
├── .env                  # Configuration
├── src/
│   ├── sessionManager.js # Multi-session manager
│   ├── database/db.js    # SQLite database
│   ├── handlers/         # Message & group handlers
│   ├── commands/
│   │   ├── ai/           # AI commands
│   │   ├── media/        # Media commands
│   │   ├── group/        # Group commands
│   │   ├── fun/          # Fun commands
│   │   ├── utility/      # Utility commands
│   │   └── owner/        # Owner commands
│   └── panel/server.js   # Web panel
├── panel/public/
│   └── index.html        # Panel UI
├── sessions/             # WhatsApp sessions
└── data/xavibot.db       # SQLite database
```
