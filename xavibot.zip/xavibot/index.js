require('dotenv').config();
const { init } = require('./src/sessionManager');
const { startPanel } = require('./src/panel/server');

async function main() {
  console.log(`
╔══════════════════════════════════╗
║   🤖  XaviBot v1.0 Starting...  ║
╚══════════════════════════════════╝`);
  await init();
  startPanel();
}

main().catch(err => { console.error('Fatal:', err); process.exit(1); });
