const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  makeInMemoryStore,
} = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const pino = require('pino');
const path = require('path');
const fs = require('fs-extra');
const { v4: uuidv4 } = require('uuid');
const { Sessions, initDatabase } = require('../database/db');
const { messageHandler } = require('../handlers/messageHandler');
const { groupEventHandler } = require('../handlers/groupEventHandler');

const SESSION_DIR = process.env.SESSION_PATH || './sessions';
const activeSessions = new Map(); // sessionId -> { socket, store }
let io = null; // socket.io instance for real-time panel updates

function setSocketIO(socketIO) {
  io = socketIO;
}

function emitToPanel(event, data) {
  if (io) io.emit(event, data);
}

async function createSession(phone, name = 'XaviBot User') {
  await fs.ensureDir(SESSION_DIR);

  // Check if session already exists
  let session = Sessions.getByPhone.get(phone);
  if (session && session.is_active) {
    return { success: false, message: 'Session already active for this number' };
  }

  const sessionId = session ? session.id : uuidv4();
  const sessionPath = path.join(SESSION_DIR, sessionId);
  await fs.ensureDir(sessionPath);

  if (!session) {
    Sessions.create.run(sessionId, phone, name, 'pending');
  }

  try {
    await startSession(sessionId, phone, true);
    return { success: true, sessionId, message: 'Session creation started' };
  } catch (err) {
    console.error(`Failed to create session ${sessionId}:`, err);
    return { success: false, message: err.message };
  }
}

async function startSession(sessionId, phone, usePairingCode = false) {
  const sessionPath = path.join(SESSION_DIR, sessionId);
  await fs.ensureDir(sessionPath);

  const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
  const { version } = await fetchLatestBaileysVersion();

  const logger = pino({ level: 'silent' });

  const store = makeInMemoryStore({ logger });
  const storePath = path.join(sessionPath, 'store.json');
  store.readFromFile(storePath);
  setInterval(() => store.writeToFile(storePath), 10_000);

  const sock = makeWASocket({
    version,
    logger,
    printQRInTerminal: false,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger),
    },
    browser: ['XaviBot', 'Chrome', '3.0'],
    markOnlineOnConnect: true,
    generateHighQualityLinkPreview: true,
    getMessage: async (key) => {
      if (store) {
        const msg = await store.loadMessage(key.remoteJid, key.id);
        return msg?.message || undefined;
      }
      return { conversation: 'hello' };
    },
  });

  store.bind(sock.ev);

  // Handle pairing code
  if (usePairingCode && !sock.authState.creds.registered) {
    setTimeout(async () => {
      try {
        const cleanPhone = phone.replace(/[^0-9]/g, '');
        const code = await sock.requestPairingCode(cleanPhone);
        Sessions.updatePairingCode.run(code, sessionId);
        Sessions.updateStatus.run('pairing', sessionId);
        emitToPanel('pairing_code', { sessionId, phone, code });
        console.log(`📱 Pairing code for ${phone}: ${code}`);
      } catch (err) {
        console.error('Pairing code error:', err);
        emitToPanel('session_error', { sessionId, error: err.message });
      }
    }, 3000);
  }

  // Connection updates
  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      emitToPanel('qr_code', { sessionId, qr });
    }

    if (connection === 'close') {
      const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
      console.log(`❌ Session ${sessionId} disconnected. Reason: ${reason}`);

      if (reason === DisconnectReason.loggedOut) {
        Sessions.updateStatus.run('logged_out', sessionId);
        Sessions.setActive.run(0, sessionId);
        activeSessions.delete(sessionId);
        await fs.remove(path.join(SESSION_DIR, sessionId));
        emitToPanel('session_disconnected', { sessionId, reason: 'Logged out' });
      } else if (reason === DisconnectReason.connectionClosed ||
                 reason === DisconnectReason.connectionLost ||
                 reason === DisconnectReason.timedOut) {
        console.log(`🔄 Reconnecting session ${sessionId}...`);
        setTimeout(() => startSession(sessionId, phone, false), 5000);
      } else if (reason === DisconnectReason.restartRequired) {
        startSession(sessionId, phone, false);
      } else {
        Sessions.updateStatus.run('disconnected', sessionId);
        activeSessions.delete(sessionId);
        emitToPanel('session_disconnected', { sessionId, reason });
      }
    }

    if (connection === 'open') {
      const info = sock.user;
      Sessions.updateStatus.run('connected', sessionId);
      Sessions.setActive.run(1, sessionId);
      activeSessions.set(sessionId, { sock, store, phone });

      emitToPanel('session_connected', {
        sessionId,
        phone,
        name: info?.name || phone,
        jid: info?.id,
      });

      console.log(`✅ Session ${sessionId} connected as ${info?.name || phone}`);

      // Send welcome to owner
      try {
        const ownerJid = `${process.env.OWNER_NUMBER}@s.whatsapp.net`;
        await sock.sendMessage(ownerJid, {
          text: `╔══════════════════╗\n║   *XaviBot* 🤖   ║\n╚══════════════════╝\n\n✅ *Bot Connected!*\n📱 Number: ${phone}\n⏰ Time: ${new Date().toLocaleString()}\n\nType *.help* to see all commands!`
        });
      } catch (_) {}
    }
  });

  // Save credentials
  sock.ev.on('creds.update', saveCreds);

  // Messages
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const msg of messages) {
      if (!msg.message) continue;
      try {
        await messageHandler(sock, msg, sessionId, store);
        Sessions.incMessages.run(sessionId);
      } catch (err) {
        console.error('Message handler error:', err);
      }
    }
  });

  // Group events
  sock.ev.on('group-participants.update', async (update) => {
    try {
      await groupEventHandler(sock, update, sessionId);
    } catch (err) {
      console.error('Group event error:', err);
    }
  });

  activeSessions.set(sessionId, { sock, store, phone });
  return sock;
}

async function loadExistingSessions() {
  const sessions = Sessions.getActive.all();
  console.log(`📂 Loading ${sessions.length} existing session(s)...`);

  for (const session of sessions) {
    const sessionPath = path.join(SESSION_DIR, session.id);
    if (await fs.pathExists(sessionPath)) {
      try {
        await startSession(session.id, session.phone, false);
        console.log(`✅ Loaded session: ${session.phone}`);
      } catch (err) {
        console.error(`Failed to load session ${session.id}:`, err);
      }
    }
  }
}

async function deleteSession(sessionId) {
  const entry = activeSessions.get(sessionId);
  if (entry) {
    try { await entry.sock.logout(); } catch (_) {}
    activeSessions.delete(sessionId);
  }
  Sessions.setActive.run(0, sessionId);
  Sessions.updateStatus.run('deleted', sessionId);
  await fs.remove(path.join(SESSION_DIR, sessionId));
  emitToPanel('session_deleted', { sessionId });
  return { success: true };
}

function getActiveSessions() {
  return activeSessions;
}

function getSession(sessionId) {
  return activeSessions.get(sessionId);
}

async function init() {
  initDatabase();
  await fs.ensureDir(SESSION_DIR);
  await loadExistingSessions();
}

module.exports = {
  init,
  createSession,
  deleteSession,
  getActiveSessions,
  getSession,
  setSocketIO,
};
