const { proto } = require('@whiskeysockets/baileys');

function isOwner(number) {
  const ownerNum = (process.env.OWNER_NUMBER || '').replace(/[^0-9]/g, '');
  const clean = (number || '').replace(/[^0-9]/g, '');
  return clean === ownerNum;
}

function isAdmin(participants, jid) {
  return participants
    .filter(p => p.admin)
    .map(p => p.id)
    .includes(jid);
}

function isBanned(user) {
  return user?.is_banned === 1;
}

function getPrefix() {
  return process.env.BOT_PREFIX || '.';
}

function extractMessage(message) {
  if (!message) return { body: '', type: 'unknown', quoted: null };

  const type = Object.keys(message)[0];
  let body = '';
  let quoted = null;

  if (message.conversation) {
    body = message.conversation;
  } else if (message.extendedTextMessage) {
    body = message.extendedTextMessage.text;
    if (message.extendedTextMessage.contextInfo?.quotedMessage) {
      quoted = message.extendedTextMessage.contextInfo;
    }
  } else if (message.imageMessage) {
    body = message.imageMessage.caption || '';
  } else if (message.videoMessage) {
    body = message.videoMessage.caption || '';
  } else if (message.documentMessage) {
    body = message.documentMessage.caption || '';
  } else if (message.buttonsResponseMessage) {
    body = message.buttonsResponseMessage.selectedButtonId || '';
  } else if (message.listResponseMessage) {
    body = message.listResponseMessage.singleSelectReply?.selectedRowId || '';
  }

  return { body, type, quoted };
}

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1048576).toFixed(1)} MB`;
}

function formatDuration(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${m}:${String(s).padStart(2, '0')}`;
}

function timeAgo(date) {
  const diff = Date.now() - new Date(date).getTime();
  const mins = Math.floor(diff / 60000);
  const hrs = Math.floor(mins / 60);
  const days = Math.floor(hrs / 24);
  if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
  if (hrs > 0) return `${hrs} hour${hrs > 1 ? 's' : ''} ago`;
  if (mins > 0) return `${mins} minute${mins > 1 ? 's' : ''} ago`;
  return 'just now';
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomChoice(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function truncate(str, len = 100) {
  return str.length > len ? str.slice(0, len) + '...' : str;
}

function cleanJid(jid) {
  return jid?.replace(/:[0-9]+@/, '@') || '';
}

function mentionJid(jid) {
  const number = jid.replace('@s.whatsapp.net', '');
  return `@${number}`;
}

function parseTime(str) {
  // Parse time strings like "1h", "30m", "2d"
  const match = str.match(/^(\d+)([smhd])$/);
  if (!match) return null;
  const val = parseInt(match[1]);
  const unit = match[2];
  const multipliers = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
  return val * (multipliers[unit] || 0);
}

async function downloadMedia(sock, message) {
  const { downloadMediaMessage } = require('@whiskeysockets/baileys');
  try {
    const buffer = await downloadMediaMessage(
      message,
      'buffer',
      {},
      { logger: require('pino')({ level: 'silent' }), reuploadRequest: sock.updateMediaMessage }
    );
    return buffer;
  } catch (err) {
    console.error('Download media error:', err);
    return null;
  }
}

function getMediaType(message) {
  if (!message?.message) return null;
  const types = ['imageMessage', 'videoMessage', 'audioMessage', 'stickerMessage', 'documentMessage'];
  for (const t of types) {
    if (message.message[t]) return t;
  }
  if (message.message.extendedTextMessage?.contextInfo?.quotedMessage) {
    const q = message.message.extendedTextMessage.contextInfo.quotedMessage;
    for (const t of types) {
      if (q[t]) return t;
    }
  }
  return null;
}

function buildHelpText(commands, category) {
  const PREFIX = process.env.BOT_PREFIX || '.';
  let text = `*━━━━━━━━━━━━━━━━━*\n`;
  text += `*🤖 XaviBot - ${category}*\n`;
  text += `*━━━━━━━━━━━━━━━━━*\n\n`;

  const seen = new Set();
  for (const [name, cmd] of Object.entries(commands)) {
    if (seen.has(cmd)) continue;
    seen.add(cmd);
    text += `▸ *${PREFIX}${name}*`;
    if (cmd.usage) text += ` ${cmd.usage}`;
    text += `\n  ${cmd.description || 'No description'}\n\n`;
  }
  return text.trim();
}

module.exports = {
  isOwner,
  isAdmin,
  isBanned,
  getPrefix,
  extractMessage,
  formatBytes,
  formatDuration,
  timeAgo,
  sleep,
  randomInt,
  randomChoice,
  truncate,
  cleanJid,
  mentionJid,
  parseTime,
  downloadMedia,
  getMediaType,
  buildHelpText,
};
