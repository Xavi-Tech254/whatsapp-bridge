const { Groups, Users, Notes, Polls } = require('../../database/db');
const { randomChoice } = require('../../utils/helpers');

// ─── KICK ─────────────────────────────────────────────────────────────────
const kick = {
  description: 'Kick a member from the group',
  usage: '@user',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!mentioned.length) return ctx.reply('❌ Mention a user to kick. Usage: .kick @user');
    if (!ctx.isBotAdmin) return ctx.reply('❌ Bot needs to be admin to kick members.');
    for (const jid of mentioned) {
      await ctx.sock.groupParticipantsUpdate(ctx.remoteJid, [jid], 'remove');
    }
    return ctx.reply(`✅ Kicked ${mentioned.length} member(s).`);
  },
};

// ─── ADD ──────────────────────────────────────────────────────────────────
const add = {
  description: 'Add a member to the group',
  usage: '<number>',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    if (!ctx.args[0]) return ctx.reply('❌ Usage: .add <phone number>');
    if (!ctx.isBotAdmin) return ctx.reply('❌ Bot needs to be admin to add members.');
    const number = ctx.args[0].replace(/[^0-9]/g, '');
    const jid = `${number}@s.whatsapp.net`;
    try {
      await ctx.sock.groupParticipantsUpdate(ctx.remoteJid, [jid], 'add');
      return ctx.reply(`✅ Added ${number} to the group.`);
    } catch (e) {
      return ctx.reply(`❌ Failed to add ${number}. They may have privacy settings enabled.`);
    }
  },
};

// ─── PROMOTE ──────────────────────────────────────────────────────────────
const promote = {
  description: 'Promote a member to admin',
  usage: '@user',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!mentioned.length) return ctx.reply('❌ Mention a user. Usage: .promote @user');
    if (!ctx.isBotAdmin) return ctx.reply('❌ Bot needs to be admin.');
    await ctx.sock.groupParticipantsUpdate(ctx.remoteJid, mentioned, 'promote');
    return ctx.reply(`✅ Promoted ${mentioned.length} member(s) to admin! 👑`);
  },
};

// ─── DEMOTE ───────────────────────────────────────────────────────────────
const demote = {
  description: 'Demote an admin to member',
  usage: '@user',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!mentioned.length) return ctx.reply('❌ Mention a user. Usage: .demote @user');
    if (!ctx.isBotAdmin) return ctx.reply('❌ Bot needs to be admin.');
    await ctx.sock.groupParticipantsUpdate(ctx.remoteJid, mentioned, 'demote');
    return ctx.reply(`✅ Demoted ${mentioned.length} admin(s) to member.`);
  },
};

// ─── MUTE / UNMUTE ────────────────────────────────────────────────────────
const mute = {
  description: 'Mute the group (only admins can send)',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    if (!ctx.isBotAdmin) return ctx.reply('❌ Bot needs to be admin.');
    await ctx.sock.groupSettingUpdate(ctx.remoteJid, 'announcement');
    Groups.setLocked.run(1, ctx.remoteJid, ctx.sessionId);
    return ctx.reply('🔇 Group has been *muted*. Only admins can send messages.');
  },
};

const unmute = {
  description: 'Unmute the group',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    if (!ctx.isBotAdmin) return ctx.reply('❌ Bot needs to be admin.');
    await ctx.sock.groupSettingUpdate(ctx.remoteJid, 'not_announcement');
    Groups.setLocked.run(0, ctx.remoteJid, ctx.sessionId);
    return ctx.reply('🔊 Group has been *unmuted*. Everyone can send messages.');
  },
};

// ─── LOCK / UNLOCK ────────────────────────────────────────────────────────
const lock = {
  description: 'Lock group settings to admins only',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    if (!ctx.isBotAdmin) return ctx.reply('❌ Bot needs to be admin.');
    await ctx.sock.groupSettingUpdate(ctx.remoteJid, 'locked');
    return ctx.reply('🔒 Group settings locked to *admins only*.');
  },
};

const unlock = {
  description: 'Allow all members to edit group info',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    if (!ctx.isBotAdmin) return ctx.reply('❌ Bot needs to be admin.');
    await ctx.sock.groupSettingUpdate(ctx.remoteJid, 'unlocked');
    return ctx.reply('🔓 Group settings *unlocked*. All members can edit.');
  },
};

// ─── WELCOME ──────────────────────────────────────────────────────────────
const welcome = {
  description: 'Toggle welcome messages',
  usage: 'on/off [custom message]',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    const [toggle, ...rest] = ctx.args;
    if (!toggle) return ctx.reply('❌ Usage: .welcome on/off [custom message]');
    const on = toggle === 'on';
    const msg = rest.join(' ') || 'Welcome {user} to {group}! 👋';
    Groups.upsert.run(ctx.remoteJid, ctx.sessionId, ctx.groupMeta?.subject || 'Group');
    Groups.setWelcome.run(on ? 1 : 0, msg, ctx.remoteJid, ctx.sessionId);
    return ctx.reply(`✅ Welcome messages *${on ? 'enabled' : 'disabled'}*\n${on ? `Message: ${msg}` : ''}`);
  },
};

// ─── GOODBYE ──────────────────────────────────────────────────────────────
const goodbye = {
  description: 'Toggle goodbye messages',
  usage: 'on/off [custom message]',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    const [toggle, ...rest] = ctx.args;
    if (!toggle) return ctx.reply('❌ Usage: .goodbye on/off [custom message]');
    const on = toggle === 'on';
    const msg = rest.join(' ') || 'Goodbye {user}! We will miss you 👋';
    Groups.upsert.run(ctx.remoteJid, ctx.sessionId, ctx.groupMeta?.subject || 'Group');
    Groups.setGoodbye.run(on ? 1 : 0, msg, ctx.remoteJid, ctx.sessionId);
    return ctx.reply(`✅ Goodbye messages *${on ? 'enabled' : 'disabled'}*`);
  },
};

// ─── ANTILINK ─────────────────────────────────────────────────────────────
const antilink = {
  description: 'Toggle anti-link protection',
  usage: 'on/off',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    const on = ctx.args[0] === 'on';
    Groups.upsert.run(ctx.remoteJid, ctx.sessionId, ctx.groupMeta?.subject || 'Group');
    Groups.setAntilink.run(on ? 1 : 0, ctx.remoteJid, ctx.sessionId);
    return ctx.reply(`🔗 Anti-link protection *${on ? 'enabled ✅' : 'disabled ❌'}*`);
  },
};

// ─── ANTISPAM ─────────────────────────────────────────────────────────────
const antispam = {
  description: 'Toggle anti-spam protection',
  usage: 'on/off',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    const on = ctx.args[0] === 'on';
    Groups.upsert.run(ctx.remoteJid, ctx.sessionId, ctx.groupMeta?.subject || 'Group');
    Groups.setAntispam.run(on ? 1 : 0, ctx.remoteJid, ctx.sessionId);
    return ctx.reply(`🛡️ Anti-spam *${on ? 'enabled ✅' : 'disabled ❌'}*`);
  },
};

// ─── WARN ─────────────────────────────────────────────────────────────────
const warn = {
  description: 'Warn a group member',
  usage: '@user [reason]',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!mentioned.length) return ctx.reply('❌ Mention a user. Usage: .warn @user [reason]');
    const target = mentioned[0];
    const reason = ctx.args.slice(1).join(' ') || 'No reason given';
    Users.upsert.run(target, ctx.sessionId, '');
    Users.addWarning.run(target, ctx.sessionId);
    const user = Users.get.get(target, ctx.sessionId);
    const number = target.replace('@s.whatsapp.net', '');
    await ctx.sock.sendMessage(ctx.remoteJid, {
      text: `⚠️ *Warning Issued*\n\n@${number} has been warned!\nReason: ${reason}\nWarnings: ${user?.warnings || 1}/3\n\n${user?.warnings >= 3 ? '🚫 Maximum warnings reached!' : ''}`,
      mentions: [target],
    });
    if (user?.warnings >= 3 && ctx.isBotAdmin) {
      await ctx.sock.groupParticipantsUpdate(ctx.remoteJid, [target], 'remove');
      await ctx.sock.sendMessage(ctx.remoteJid, { text: `🚫 @${number} was kicked for reaching 3 warnings.`, mentions: [target] });
    }
  },
};

// ─── WARNINGS ─────────────────────────────────────────────────────────────
const warnings = {
  description: 'Check warnings for a user',
  usage: '@user',
  groupOnly: true,
  async execute(ctx) {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [ctx.senderJid];
    const target = mentioned[0];
    const user = Users.get.get(target, ctx.sessionId);
    const number = target.replace('@s.whatsapp.net', '');
    return ctx.reply(`⚠️ *Warnings for @${number}*\n\nCount: ${user?.warnings || 0}/3`);
  },
};

// ─── RESETWARN ────────────────────────────────────────────────────────────
const resetwarn = {
  description: 'Reset warnings for a user',
  usage: '@user',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!mentioned.length) return ctx.reply('❌ Mention a user.');
    Users.resetWarnings.run(mentioned[0], ctx.sessionId);
    const number = mentioned[0].replace('@s.whatsapp.net', '');
    return ctx.reply(`✅ Warnings reset for @${number}`);
  },
};

// ─── BAN / UNBAN ──────────────────────────────────────────────────────────
const ban = {
  description: 'Ban a user from using the bot',
  usage: '@user',
  adminOnly: true,
  async execute(ctx) {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!mentioned.length) return ctx.reply('❌ Mention a user. Usage: .ban @user');
    for (const jid of mentioned) {
      Users.upsert.run(jid, ctx.sessionId, '');
      Users.ban.run(jid, ctx.sessionId);
    }
    return ctx.reply(`🚫 Banned ${mentioned.length} user(s) from using the bot.`);
  },
};

const unban = {
  description: 'Unban a user',
  usage: '@user',
  adminOnly: true,
  async execute(ctx) {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!mentioned.length) return ctx.reply('❌ Mention a user. Usage: .unban @user');
    for (const jid of mentioned) {
      Users.unban.run(jid, ctx.sessionId);
    }
    return ctx.reply(`✅ Unbanned ${mentioned.length} user(s).`);
  },
};

// ─── TAGALL ───────────────────────────────────────────────────────────────
const tagall = {
  description: 'Tag all group members with a message',
  usage: '[message]',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    const meta = ctx.groupMeta;
    const members = meta.participants.map(p => p.id);
    const msg = ctx.query || '📢 Attention everyone!';
    const mentions = members.map(m => `@${m.replace('@s.whatsapp.net', '')}`).join(' ');
    await ctx.sock.sendMessage(ctx.remoteJid, {
      text: `${msg}\n\n${mentions}`,
      mentions: members,
    });
  },
};

// ─── HIDETAG ──────────────────────────────────────────────────────────────
const hidetag = {
  description: 'Tag all members silently',
  usage: '<message>',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    const meta = ctx.groupMeta;
    const members = meta.participants.map(p => p.id);
    const msg = ctx.query || '📢';
    await ctx.sock.sendMessage(ctx.remoteJid, {
      text: msg,
      mentions: members,
    });
  },
};

// ─── NOTE ─────────────────────────────────────────────────────────────────
const note = {
  description: 'Save a note in this group',
  usage: '<name> <content>',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    const [name, ...rest] = ctx.args;
    if (!name || !rest.length) return ctx.reply('❌ Usage: .note <name> <content>');
    Notes.set.run(ctx.sessionId, ctx.remoteJid, name, rest.join(' '));
    return ctx.reply(`✅ Note *${name}* saved!`);
  },
};

const getnote = {
  description: 'Retrieve a saved note',
  usage: '<name>',
  aliases: ['#'],
  groupOnly: true,
  async execute(ctx) {
    const name = ctx.args[0];
    if (!name) return ctx.reply('❌ Usage: .getnote <name>');
    const n = Notes.get.get(ctx.sessionId, name, ctx.remoteJid);
    if (!n) return ctx.reply(`❌ Note *${name}* not found.`);
    return ctx.reply(`📝 *${n.name}*\n\n${n.content}`);
  },
};

const notes = {
  description: 'List all saved notes',
  groupOnly: true,
  async execute(ctx) {
    const all = Notes.getAll.all(ctx.sessionId, ctx.remoteJid);
    if (!all.length) return ctx.reply('📭 No notes saved in this group.');
    return ctx.reply(`📋 *Saved Notes*\n\n${all.map(n => `• ${n.name}`).join('\n')}`);
  },
};

const delnote = {
  description: 'Delete a saved note',
  usage: '<name>',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    const name = ctx.args[0];
    if (!name) return ctx.reply('❌ Usage: .delnote <name>');
    Notes.delete.run(ctx.sessionId, name, ctx.remoteJid);
    return ctx.reply(`🗑️ Note *${name}* deleted.`);
  },
};

// ─── POLL ─────────────────────────────────────────────────────────────────
const poll = {
  description: 'Create a poll',
  usage: '<question>|<option1>|<option2>|...',
  groupOnly: true,
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .poll Question|Option1|Option2|Option3');
    const parts = ctx.query.split('|').map(p => p.trim());
    if (parts.length < 3) return ctx.reply('❌ Need at least a question and 2 options.\nExample: .poll Favorite color?|Red|Blue|Green');
    const [question, ...options] = parts;
    const result = Polls.create.run(ctx.sessionId, ctx.remoteJid, question, JSON.stringify(options), ctx.senderJid);
    const optText = options.map((o, i) => `${['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣'][i]} ${o}`).join('\n');
    return ctx.reply(
      `📊 *Poll Created!*\n\n*${question}*\n\n${optText}\n\n_Vote with .vote 1/2/3..._\n_End poll with .endpoll_\n_View results with .pollresults_`
    );
  },
};

const vote = {
  description: 'Vote in an active poll',
  usage: '<number>',
  groupOnly: true,
  async execute(ctx) {
    const choice = parseInt(ctx.args[0]);
    if (!choice) return ctx.reply('❌ Usage: .vote <number>');
    const activePoll = Polls.getActive.get(ctx.remoteJid, ctx.sessionId);
    if (!activePoll) return ctx.reply('❌ No active poll. Create one with .poll');
    const options = JSON.parse(activePoll.options);
    if (choice < 1 || choice > options.length) return ctx.reply(`❌ Choose between 1 and ${options.length}`);
    const votes = JSON.parse(activePoll.votes || '{}');
    votes[ctx.senderJid] = choice - 1;
    Polls.updateVotes.run(JSON.stringify(votes), activePoll.id);
    return ctx.reply(`✅ Vote recorded for: *${options[choice - 1]}*`);
  },
};

const pollresults = {
  description: 'View current poll results',
  groupOnly: true,
  async execute(ctx) {
    const activePoll = Polls.getActive.get(ctx.remoteJid, ctx.sessionId);
    if (!activePoll) return ctx.reply('❌ No active poll.');
    const options = JSON.parse(activePoll.options);
    const votes = JSON.parse(activePoll.votes || '{}');
    const counts = options.map((_, i) => Object.values(votes).filter(v => v === i).length);
    const total = Object.keys(votes).length;
    const results = options.map((o, i) => {
      const pct = total ? Math.round((counts[i] / total) * 100) : 0;
      const bar = '█'.repeat(Math.floor(pct / 10)) + '░'.repeat(10 - Math.floor(pct / 10));
      return `${o}\n${bar} ${pct}% (${counts[i]} votes)`;
    }).join('\n\n');
    return ctx.reply(`📊 *Poll Results*\n\n*${activePoll.question}*\n\n${results}\n\nTotal votes: ${total}`);
  },
};

const endpoll = {
  description: 'End an active poll',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    const activePoll = Polls.getActive.get(ctx.remoteJid, ctx.sessionId);
    if (!activePoll) return ctx.reply('❌ No active poll to end.');
    Polls.end.run(activePoll.id);
    const options = JSON.parse(activePoll.options);
    const votes = JSON.parse(activePoll.votes || '{}');
    const counts = options.map((_, i) => Object.values(votes).filter(v => v === i).length);
    const winnerIdx = counts.indexOf(Math.max(...counts));
    return ctx.reply(`🏁 *Poll Ended!*\n\n*${activePoll.question}*\n\n🏆 Winner: *${options[winnerIdx]}* with ${counts[winnerIdx]} votes!\nTotal votes: ${Object.keys(votes).length}`);
  },
};

// ─── SETNAME ──────────────────────────────────────────────────────────────
const setname = {
  description: 'Change group name',
  usage: '<new name>',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .setname <new group name>');
    if (!ctx.isBotAdmin) return ctx.reply('❌ Bot needs to be admin.');
    await ctx.sock.groupUpdateSubject(ctx.remoteJid, ctx.query);
    return ctx.reply(`✅ Group name changed to *${ctx.query}*`);
  },
};

// ─── SETDESC ──────────────────────────────────────────────────────────────
const setdesc = {
  description: 'Change group description',
  usage: '<description>',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .setdesc <description>');
    if (!ctx.isBotAdmin) return ctx.reply('❌ Bot needs to be admin.');
    await ctx.sock.groupUpdateDescription(ctx.remoteJid, ctx.query);
    return ctx.reply(`✅ Group description updated!`);
  },
};

// ─── INVITELINK ───────────────────────────────────────────────────────────
const invitelink = {
  description: 'Get group invite link',
  adminOnly: true,
  groupOnly: true,
  aliases: ['link', 'invite'],
  async execute(ctx) {
    try {
      const code = await ctx.sock.groupInviteCode(ctx.remoteJid);
      return ctx.reply(`🔗 *Group Invite Link*\n\nhttps://chat.whatsapp.com/${code}`);
    } catch (e) {
      return ctx.reply('❌ Could not get invite link. Bot must be admin.');
    }
  },
};

// ─── REVOKELINK ───────────────────────────────────────────────────────────
const revokelink = {
  description: 'Revoke and reset group invite link',
  adminOnly: true,
  groupOnly: true,
  async execute(ctx) {
    if (!ctx.isBotAdmin) return ctx.reply('❌ Bot needs to be admin.');
    try {
      const code = await ctx.sock.groupRevokeInvite(ctx.remoteJid);
      return ctx.reply(`✅ Invite link revoked!\n\nNew link: https://chat.whatsapp.com/${code}`);
    } catch (e) {
      return ctx.reply('❌ Failed to revoke link.');
    }
  },
};

// ─── ADMINS ───────────────────────────────────────────────────────────────
const admins = {
  description: 'List all group admins',
  groupOnly: true,
  async execute(ctx) {
    const meta = ctx.groupMeta;
    const adminList = meta.participants.filter(p => p.admin);
    const text = adminList.map(a => `👑 @${a.id.replace('@s.whatsapp.net', '')}`).join('\n');
    await ctx.sock.sendMessage(ctx.remoteJid, {
      text: `🛡️ *Group Admins (${adminList.length})*\n\n${text}`,
      mentions: adminList.map(a => a.id),
    });
  },
};

// ─── MEMBERS ──────────────────────────────────────────────────────────────
const members = {
  description: 'Show member count',
  groupOnly: true,
  async execute(ctx) {
    const meta = ctx.groupMeta;
    return ctx.reply(
      `👥 *Group Members*\n\n` +
      `Total: ${meta.participants.length}\n` +
      `Admins: ${meta.participants.filter(p => p.admin).length}\n` +
      `Members: ${meta.participants.filter(p => !p.admin).length}`
    );
  },
};

module.exports = {
  kick, add, promote, demote,
  mute, unmute, lock, unlock,
  welcome, goodbye, antilink, antispam,
  warn, warnings, resetwarn, ban, unban,
  tagall, hidetag,
  note, getnote, notes, delnote,
  poll, vote, pollresults, endpoll,
  setname, setdesc, invitelink, revokelink,
  admins, members,
};
