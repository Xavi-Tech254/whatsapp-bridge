const { Sessions, Users, Economy } = require('../../database/db');
const { getActiveSessions } = require('../../sessionManager');

const ownerhelp = {
  description: 'Show owner commands',
  ownerOnly: true,
  async execute(ctx) {
    const P = ctx.PREFIX;
    return ctx.reply(
      `*━━━ 👑 OWNER COMMANDS ━━━*\n\n` +
      `▸ ${P}broadcast <msg> — Broadcast to all chats\n` +
      `▸ ${P}setpremium @user — Set premium user\n` +
      `▸ ${P}removepremium @user — Remove premium\n` +
      `▸ ${P}givecoins @user <amount> — Give coins\n` +
      `▸ ${P}restart — Restart bot\n` +
      `▸ ${P}botstats — Detailed bot stats\n` +
      `▸ ${P}listgroups — List all groups\n` +
      `▸ ${P}listchats — List all chats\n` +
      `▸ ${P}cleardb — Clear command logs\n` +
      `▸ ${P}setprefix <char> — Change prefix\n` +
      `▸ ${P}joingroup <link> — Join group via link\n` +
      `▸ ${P}leavegroup <jid> — Leave a group`
    );
  },
};

const broadcast = {
  description: 'Broadcast a message to all chats',
  usage: '<message>',
  ownerOnly: true,
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .broadcast <message>');
    const { sock } = ctx;
    const chats = await sock.groupFetchAllParticipating();
    const groups = Object.keys(chats);
    let sent = 0, failed = 0;
    await ctx.reply(`📡 Broadcasting to ${groups.length} groups...`);
    for (const jid of groups) {
      try {
        await sock.sendMessage(jid, {
          text: `📢 *Broadcast from XaviBot*\n\n${ctx.query}\n\n_Sent by owner_`
        });
        sent++;
        await new Promise(r => setTimeout(r, 1000));
      } catch (_) { failed++; }
    }
    return ctx.reply(`✅ Broadcast done!\n✅ Sent: ${sent}\n❌ Failed: ${failed}`);
  },
};

const setpremium = {
  description: 'Grant premium to a user',
  usage: '@user',
  ownerOnly: true,
  async execute(ctx) {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!mentioned.length) return ctx.reply('❌ Mention a user.');
    for (const jid of mentioned) {
      Users.upsert.run(jid, ctx.sessionId, '');
      Users.setPremium.run(1, jid, ctx.sessionId);
    }
    return ctx.reply(`✅ Premium granted to ${mentioned.length} user(s).`);
  },
};

const removepremium = {
  description: 'Remove premium from a user',
  usage: '@user',
  ownerOnly: true,
  async execute(ctx) {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!mentioned.length) return ctx.reply('❌ Mention a user.');
    for (const jid of mentioned) {
      Users.setPremium.run(0, jid, ctx.sessionId);
    }
    return ctx.reply(`✅ Premium removed from ${mentioned.length} user(s).`);
  },
};

const givecoins = {
  description: 'Give coins to a user',
  usage: '@user <amount>',
  ownerOnly: true,
  async execute(ctx) {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    const amount = parseInt(ctx.args[1]);
    if (!mentioned.length || !amount) return ctx.reply('❌ Usage: .givecoins @user <amount>');
    Economy.init.run(mentioned[0], ctx.sessionId);
    Economy.addCoins.run(amount, mentioned[0], ctx.sessionId);
    return ctx.reply(`✅ Gave *${amount} coins* to @${mentioned[0].replace('@s.whatsapp.net', '')}`);
  },
};

const botstats = {
  description: 'View detailed bot statistics',
  ownerOnly: true,
  async execute(ctx) {
    const { Logs, Sessions: S } = require('../../database/db');
    const allSessions = S.getAll.all();
    const active = S.countActive.get();
    const logs = Logs.totalCount.get(ctx.sessionId);
    const topCmds = Logs.getStats.all(ctx.sessionId);
    const topText = topCmds.map((c, i) => `${i + 1}. .${c.command} (${c.count}x)`).join('\n');
    const mem = process.memoryUsage();
    return ctx.reply(
      `📊 *XaviBot Statistics*\n\n` +
      `🤖 Total Sessions: ${allSessions.length}\n` +
      `✅ Active: ${active?.count || 0}\n` +
      `💬 Commands Run: ${logs?.count || 0}\n` +
      `⏱️ Uptime: ${Math.floor(process.uptime() / 60)}m\n` +
      `💾 Memory: ${Math.round(mem.rss / 1024 / 1024)}MB\n\n` +
      `📈 *Top Commands:*\n${topText}`
    );
  },
};

const listgroups = {
  description: 'List all groups the bot is in',
  ownerOnly: true,
  async execute(ctx) {
    try {
      const chats = await ctx.sock.groupFetchAllParticipating();
      const groups = Object.values(chats);
      if (!groups.length) return ctx.reply('📭 Not in any groups.');
      const text = groups.slice(0, 20).map((g, i) => `${i + 1}. *${g.subject}* (${g.participants.length} members)`).join('\n');
      return ctx.reply(`👥 *Groups (${groups.length})*\n\n${text}${groups.length > 20 ? '\n\n_...and more_' : ''}`);
    } catch (e) {
      return ctx.reply('❌ Failed to fetch groups.');
    }
  },
};

const restart = {
  description: 'Restart the bot process',
  ownerOnly: true,
  async execute(ctx) {
    await ctx.reply('♻️ Restarting XaviBot...');
    setTimeout(() => process.exit(0), 2000);
  },
};

const setprefix = {
  description: 'Change the bot command prefix',
  usage: '<character>',
  ownerOnly: true,
  async execute(ctx) {
    const p = ctx.args[0];
    if (!p || p.length > 2) return ctx.reply('❌ Usage: .setprefix <character>');
    process.env.BOT_PREFIX = p;
    return ctx.reply(`✅ Prefix changed to *${p}*\nExample: ${p}help`);
  },
};

const joingroup = {
  description: 'Join a group via invite link',
  usage: '<invite link>',
  ownerOnly: true,
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .joingroup <invite link>');
    try {
      const code = ctx.query.split('chat.whatsapp.com/').pop();
      await ctx.sock.groupAcceptInvite(code);
      return ctx.reply('✅ Joined group successfully!');
    } catch (e) {
      return ctx.reply('❌ Failed to join: ' + e.message);
    }
  },
};

const leavegroup = {
  description: 'Leave a group',
  usage: '<group JID or "this">',
  ownerOnly: true,
  async execute(ctx) {
    const target = ctx.args[0] === 'this' ? ctx.remoteJid : ctx.args[0];
    if (!target) return ctx.reply('❌ Usage: .leavegroup this (or .leavegroup <jid>)');
    try {
      await ctx.sock.groupLeave(target);
      return ctx.reply('✅ Left group!');
    } catch (e) {
      return ctx.reply('❌ Failed: ' + e.message);
    }
  },
};

module.exports = {
  ownerhelp, broadcast, setpremium, removepremium,
  givecoins, botstats, listgroups, restart, setprefix,
  joingroup, leavegroup,
};
