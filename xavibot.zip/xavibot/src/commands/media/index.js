const axios = require('axios');
const { downloadMedia } = require('../../utils/helpers');

const sticker = {
  description: 'Convert image/video to sticker',
  aliases: ['s', 'stiker'],
  async execute(ctx) {
    const { sock, msg, remoteJid, quoted, sessionId } = ctx;
    let mediaMsg = msg;
    if (quoted?.quotedMessage) {
      mediaMsg = { message: quoted.quotedMessage, key: msg.key };
    }
    const hasImage = mediaMsg.message?.imageMessage;
    const hasVideo = mediaMsg.message?.videoMessage;
    if (!hasImage && !hasVideo) return ctx.reply('❌ Send or reply to an image/video with .sticker');
    try {
      const buffer = await downloadMedia(sock, mediaMsg);
      if (!buffer) return ctx.reply('❌ Failed to download media.');
      await sock.sendMessage(remoteJid, {
        sticker: buffer,
      }, { quoted: msg });
    } catch (e) {
      return ctx.reply('❌ Failed to create sticker: ' + e.message);
    }
  },
};

const toimg = {
  description: 'Convert sticker to image',
  aliases: ['stickertoimg', 'unpack'],
  async execute(ctx) {
    const { sock, msg, remoteJid, quoted } = ctx;
    let mediaMsg = msg;
    if (quoted?.quotedMessage) mediaMsg = { message: quoted.quotedMessage, key: msg.key };
    if (!mediaMsg.message?.stickerMessage) return ctx.reply('❌ Reply to a sticker with .toimg');
    try {
      const buffer = await downloadMedia(sock, mediaMsg);
      if (!buffer) return ctx.reply('❌ Download failed.');
      await sock.sendMessage(remoteJid, { image: buffer, caption: '✅ Sticker → Image' }, { quoted: msg });
    } catch (e) {
      return ctx.reply('❌ Conversion failed: ' + e.message);
    }
  },
};

const attp = {
  description: 'Create animated text sticker',
  usage: '<text>',
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .attp <text>');
    try {
      const url = `https://api.gifmaker.me/sticker?text=${encodeURIComponent(ctx.query)}&color=random`;
      const { data } = await axios.get(url, { responseType: 'arraybuffer', timeout: 15000 });
      await ctx.sock.sendMessage(ctx.remoteJid, { sticker: Buffer.from(data) }, { quoted: ctx.msg });
    } catch (e) {
      // Fallback: text sticker via API
      try {
        const { data } = await axios.get(
          `https://api.paxsenix.biz.id/sticker/text?text=${encodeURIComponent(ctx.query)}`,
          { responseType: 'arraybuffer', timeout: 15000 }
        );
        await ctx.sock.sendMessage(ctx.remoteJid, { sticker: Buffer.from(data) }, { quoted: ctx.msg });
      } catch (_) {
        return ctx.reply('❌ Text sticker failed. Try a shorter text.');
      }
    }
  },
};

const ytmp3 = {
  description: 'Download YouTube audio (MP3)',
  usage: '<url or search>',
  aliases: ['yta', 'ytaudio', 'mp3'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .ytmp3 <YouTube URL or song name>');
    await ctx.reply('⏳ Downloading audio...');
    try {
      const { data } = await axios.get(
        `https://api.paxsenix.biz.id/yt/mp3?url=${encodeURIComponent(ctx.query)}`,
        { timeout: 30000 }
      );
      if (!data.url) return ctx.reply('❌ Download failed. Try a different video.');
      const audio = await axios.get(data.url, { responseType: 'arraybuffer', timeout: 60000 });
      await ctx.sock.sendMessage(ctx.remoteJid, {
        audio: Buffer.from(audio.data),
        mimetype: 'audio/mp4',
        ptt: false,
      }, { quoted: ctx.msg });
    } catch (e) {
      return ctx.reply('❌ Failed: ' + e.message);
    }
  },
};

const ytmp4 = {
  description: 'Download YouTube video (MP4)',
  usage: '<url>',
  aliases: ['ytv', 'ytvideo', 'mp4'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .ytmp4 <YouTube URL>');
    await ctx.reply('⏳ Downloading video...');
    try {
      const { data } = await axios.get(
        `https://api.paxsenix.biz.id/yt/mp4?url=${encodeURIComponent(ctx.query)}`,
        { timeout: 30000 }
      );
      if (!data.url) return ctx.reply('❌ Download failed.');
      const video = await axios.get(data.url, { responseType: 'arraybuffer', timeout: 120000 });
      await ctx.sock.sendMessage(ctx.remoteJid, {
        video: Buffer.from(video.data),
        caption: data.title || 'Downloaded by XaviBot',
        mimetype: 'video/mp4',
      }, { quoted: ctx.msg });
    } catch (e) {
      return ctx.reply('❌ Failed: ' + e.message);
    }
  },
};

const youtube = {
  description: 'Search YouTube videos',
  usage: '<query>',
  aliases: ['ytsearch', 'yt'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .youtube <search query>');
    try {
      const { data } = await axios.get(
        `https://api.paxsenix.biz.id/yt/search?q=${encodeURIComponent(ctx.query)}`,
        { timeout: 15000 }
      );
      const results = (data.results || []).slice(0, 5);
      if (!results.length) return ctx.reply('❌ No results found.');
      const text = results.map((r, i) =>
        `${i + 1}. *${r.title}*\n   ⏱️ ${r.duration} | 👁️ ${r.views}\n   🔗 ${r.url}`
      ).join('\n\n');
      return ctx.reply(`🎬 *YouTube Results*\n\n${text}`);
    } catch (e) {
      return ctx.reply('❌ Search failed.');
    }
  },
};

const tiktok = {
  description: 'Download TikTok video (no watermark)',
  usage: '<url>',
  aliases: ['tt', 'tik'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .tiktok <TikTok URL>');
    await ctx.reply('⏳ Downloading TikTok...');
    try {
      const { data } = await axios.get(
        `https://api.paxsenix.biz.id/tiktok?url=${encodeURIComponent(ctx.query)}`,
        { timeout: 30000 }
      );
      const url = data.video || data.url || data.nowm;
      if (!url) return ctx.reply('❌ Could not extract video.');
      const video = await axios.get(url, { responseType: 'arraybuffer', timeout: 60000 });
      await ctx.sock.sendMessage(ctx.remoteJid, {
        video: Buffer.from(video.data),
        caption: data.title || 'TikTok via XaviBot',
        mimetype: 'video/mp4',
      }, { quoted: ctx.msg });
    } catch (e) {
      return ctx.reply('❌ TikTok download failed.');
    }
  },
};

const instagram = {
  description: 'Download Instagram post/reel',
  usage: '<url>',
  aliases: ['ig', 'insta'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .instagram <Instagram URL>');
    await ctx.reply('⏳ Downloading from Instagram...');
    try {
      const { data } = await axios.get(
        `https://api.paxsenix.biz.id/ig?url=${encodeURIComponent(ctx.query)}`,
        { timeout: 30000 }
      );
      const url = data.video || data.image || data.url;
      if (!url) return ctx.reply('❌ Could not extract media.');
      const media = await axios.get(url, { responseType: 'arraybuffer', timeout: 60000 });
      const isVideo = data.video || url.includes('.mp4');
      await ctx.sock.sendMessage(ctx.remoteJid, {
        [isVideo ? 'video' : 'image']: Buffer.from(media.data),
        caption: 'Downloaded via XaviBot',
      }, { quoted: ctx.msg });
    } catch (e) {
      return ctx.reply('❌ Instagram download failed.');
    }
  },
};

const spotify = {
  description: 'Search and download Spotify track',
  usage: '<song name>',
  aliases: ['sp', 'music'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .spotify <song name>');
    await ctx.reply('🎵 Searching Spotify...');
    try {
      const { data } = await axios.get(
        `https://api.paxsenix.biz.id/spotify/search?q=${encodeURIComponent(ctx.query)}`,
        { timeout: 15000 }
      );
      const track = data.tracks?.[0];
      if (!track) return ctx.reply('❌ Track not found.');
      return ctx.reply(
        `🎵 *${track.name}*\n` +
        `👤 Artist: ${track.artists}\n` +
        `💿 Album: ${track.album}\n` +
        `⏱️ Duration: ${track.duration}\n` +
        `🔗 ${track.url}\n\n` +
        `_Use .ytmp3 ${track.name} ${track.artists} to download_`
      );
    } catch (e) {
      return ctx.reply('❌ Spotify search failed.');
    }
  },
};

const lyrics = {
  description: 'Get song lyrics',
  usage: '<song name>',
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .lyrics <song name>');
    try {
      const { data } = await axios.get(
        `https://api.paxsenix.biz.id/lyrics?q=${encodeURIComponent(ctx.query)}`,
        { timeout: 15000 }
      );
      const text = data.lyrics || data.result;
      if (!text) return ctx.reply('❌ Lyrics not found.');
      const truncated = text.length > 3000 ? text.slice(0, 3000) + '\n\n_...truncated_' : text;
      return ctx.reply(`🎵 *${data.title || ctx.query}*\n\n${truncated}`);
    } catch (e) {
      return ctx.reply('❌ Lyrics not found.');
    }
  },
};

const removebg = {
  description: 'Remove background from image',
  aliases: ['rmbg', 'nobg'],
  async execute(ctx) {
    const key = process.env.REMOVEBG_API_KEY;
    if (!key) return ctx.reply('❌ REMOVEBG_API_KEY not set in .env');
    const { sock, msg, remoteJid, quoted } = ctx;
    let mediaMsg = msg;
    if (quoted?.quotedMessage) mediaMsg = { message: quoted.quotedMessage, key: msg.key };
    if (!mediaMsg.message?.imageMessage) return ctx.reply('❌ Reply to an image with .removebg');
    await ctx.reply('⏳ Removing background...');
    try {
      const buffer = await downloadMedia(sock, mediaMsg);
      const FormData = require('form-data');
      const form = new FormData();
      form.append('image_file', buffer, { filename: 'image.jpg' });
      form.append('size', 'auto');
      const { data } = await axios.post('https://api.remove.bg/v1.0/removebg', form, {
        headers: { ...form.getHeaders(), 'X-Api-Key': key },
        responseType: 'arraybuffer',
      });
      await sock.sendMessage(remoteJid, { image: Buffer.from(data), caption: '✅ Background removed!' }, { quoted: msg });
    } catch (e) {
      return ctx.reply('❌ Failed: ' + e.message);
    }
  },
};

const emojimix = {
  description: 'Mix two emojis together',
  usage: '<emoji1> <emoji2>',
  async execute(ctx) {
    const [e1, e2] = ctx.args;
    if (!e1 || !e2) return ctx.reply('❌ Usage: .emojimix 😂 🔥');
    try {
      const code1 = [...e1].map(c => c.codePointAt(0).toString(16)).join('-');
      const code2 = [...e2].map(c => c.codePointAt(0).toString(16)).join('-');
      const url = `https://www.gstatic.com/android/keyboard/emojikitchen/20201001/u${code1}/u${code1}_u${code2}.png`;
      const { data } = await axios.get(url, { responseType: 'arraybuffer', timeout: 10000 });
      await ctx.sock.sendMessage(ctx.remoteJid, {
        image: Buffer.from(data),
        caption: `${e1} + ${e2} = 🎨`,
      }, { quoted: ctx.msg });
    } catch (e) {
      return ctx.reply('❌ Emoji combination not available. Try different emojis!');
    }
  },
};

module.exports = {
  sticker, toimg, attp, ytmp3, ytmp4, youtube,
  tiktok, instagram, spotify, lyrics, removebg, emojimix,
};
