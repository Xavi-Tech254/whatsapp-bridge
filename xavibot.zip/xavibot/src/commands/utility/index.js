const axios = require('axios');
const { randomInt, randomChoice, sleep, parseTime, formatBytes } = require('../utils/helpers');
const { Notes, Todos, Reminders, Afk, Users, Sessions, Logs } = require('../database/db');
const { commandRegistry } = require('../handlers/messageHandler');
const math = require('mathjs');

// ─── HELP ──────────────────────────────────────────────────────────────────
const help = {
  description: 'Show all commands or info about a specific command',
  usage: '[command]',
  aliases: ['menu', 'commands', 'cmd'],
  async execute(ctx) {
    const { args, reply, sessionId } = ctx;
    const PREFIX = ctx.PREFIX;

    if (args[0]) {
      // Specific command help
      const handler = commandRegistry?.get(args[0].toLowerCase());
      if (handler) {
        return reply(
          `*Command: ${PREFIX}${args[0]}*\n` +
          `📋 ${handler.description || 'No description'}\n` +
          (handler.usage ? `📌 Usage: ${PREFIX}${args[0]} ${handler.usage}\n` : '') +
          (handler.aliases ? `🔁 Aliases: ${handler.aliases.join(', ')}\n` : '') +
          (handler.adminOnly ? '🛡️ Admin only\n' : '') +
          (handler.ownerOnly ? '👑 Owner only\n' : '')
        );
      }
      return reply(`❌ Command *${args[0]}* not found.`);
    }

    const stats = Logs.totalCount.get(sessionId);
    const msg = `╔══════════════════╗
║  🤖 *XaviBot* 🤖  ║
╚══════════════════╝

*🔰 Prefix:* ${PREFIX}
*📊 Total Commands Used:* ${stats?.count || 0}

*📂 Categories:*
▸ ${PREFIX}*aihelp* — AI & Smart Commands
▸ ${PREFIX}*mediahelp* — Media & Stickers
▸ ${PREFIX}*grouphelp* — Group Management
▸ ${PREFIX}*funhelp* — Fun & Games
▸ ${PREFIX}*utilityhelp* — Utility Tools
▸ ${PREFIX}*ownerhelp* — Owner Commands

*💡 Example:* ${PREFIX}ai What is the capital of Nigeria?

_Type ${PREFIX}help <command> for details_

> Powered by XaviBot 🚀`;

    return reply(msg);
  },
};

const aihelp = {
  description: 'Show AI commands',
  aliases: ['aicommands'],
  async execute(ctx) {
    const P = ctx.PREFIX;
    return ctx.reply(`*━━━ 🧠 AI COMMANDS ━━━*\n\n` +
      `▸ ${P}ai <question>\n▸ ${P}gpt <question>\n▸ ${P}imagine <prompt>\n` +
      `▸ ${P}translate <lang> <text>\n▸ ${P}summarize <text>\n▸ ${P}rewrite <text>\n` +
      `▸ ${P}grammar <text>\n▸ ${P}define <word>\n▸ ${P}synonym <word>\n` +
      `▸ ${P}antonym <word>\n▸ ${P}joke\n▸ ${P}riddle\n▸ ${P}quote\n` +
      `▸ ${P}horoscope <sign>\n▸ ${P}fact\n▸ ${P}trivia\n▸ ${P}roast @user\n▸ ${P}compliment @user`);
  },
};

const mediahelp = {
  description: 'Show media commands',
  async execute(ctx) {
    const P = ctx.PREFIX;
    return ctx.reply(`*━━━ 🎨 MEDIA COMMANDS ━━━*\n\n` +
      `▸ ${P}sticker / ${P}s — Image to sticker\n▸ ${P}toimg — Sticker to image\n` +
      `▸ ${P}tovideo — Sticker to video\n▸ ${P}attp <text> — Text sticker\n` +
      `▸ ${P}emojimix <e1> <e2> — Mix emojis\n▸ ${P}removebg — Remove background\n` +
      `▸ ${P}ytmp3 <url> — YouTube audio\n▸ ${P}ytmp4 <url> — YouTube video\n` +
      `▸ ${P}tiktok <url> — Download TikTok\n▸ ${P}instagram <url> — Download IG\n` +
      `▸ ${P}youtube <query> — Search YouTube\n▸ ${P}spotify <query> — Search Spotify\n` +
      `▸ ${P}lyrics <song> — Get lyrics`);
  },
};

const grouphelp = {
  description: 'Show group commands',
  async execute(ctx) {
    const P = ctx.PREFIX;
    return ctx.reply(`*━━━ 👥 GROUP COMMANDS ━━━*\n\n` +
      `▸ ${P}kick @user — Kick member\n▸ ${P}add <number> — Add member\n` +
      `▸ ${P}promote @user — Make admin\n▸ ${P}demote @user — Remove admin\n` +
      `▸ ${P}mute — Mute group\n▸ ${P}unmute — Unmute group\n` +
      `▸ ${P}welcome on/off — Toggle welcome\n▸ ${P}goodbye on/off — Toggle goodbye\n` +
      `▸ ${P}antilink on/off — Toggle anti-link\n▸ ${P}antispam on/off — Toggle antispam\n` +
      `▸ ${P}warn @user — Warn member\n▸ ${P}warnings @user — Check warnings\n` +
      `▸ ${P}ban @user — Ban from bot\n▸ ${P}unban @user — Unban\n` +
      `▸ ${P}hidetag <text> — Tag all silently\n▸ ${P}tagall <text> — Tag everyone\n` +
      `▸ ${P}poll <q>|<a1>|<a2> — Create poll\n▸ ${P}endpoll — End poll\n` +
      `▸ ${P}note <name> <text> — Save note\n▸ ${P}getnote <name> — Get note`);
  },
};

const funhelp = {
  description: 'Show fun commands',
  async execute(ctx) {
    const P = ctx.PREFIX;
    return ctx.reply(`*━━━ 🎉 FUN COMMANDS ━━━*\n\n` +
      `▸ ${P}8ball <question> — Magic 8-ball\n▸ ${P}roll [max] — Roll dice\n` +
      `▸ ${P}flip — Flip coin\n▸ ${P}rps <choice> — Rock paper scissors\n` +
      `▸ ${P}truth — Truth question\n▸ ${P}dare — Dare challenge\n` +
      `▸ ${P}wyr — Would you rather\n▸ ${P}ship @user1 @user2 — Ship meter\n` +
      `▸ ${P}marry @user — Propose marriage\n▸ ${P}divorce — Get divorced\n` +
      `▸ ${P}daily — Daily coins\n▸ ${P}work — Earn coins\n▸ ${P}crime — Risk crime\n` +
      `▸ ${P}balance — Check coins\n▸ ${P}deposit <amount> — Bank deposit\n` +
      `▸ ${P}withdraw <amount> — Bank withdraw\n▸ ${P}leaderboard — Top users\n` +
      `▸ ${P}tictactoe @user — Play TicTacToe\n▸ ${P}hangman — Play hangman\n▸ ${P}quiz — Start quiz`);
  },
};

const utilityhelp = {
  description: 'Show utility commands',
  async execute(ctx) {
    const P = ctx.PREFIX;
    return ctx.reply(`*━━━ 🛠️ UTILITY COMMANDS ━━━*\n\n` +
      `▸ ${P}ping — Check bot latency\n▸ ${P}uptime — Bot uptime\n` +
      `▸ ${P}calc <expr> — Calculator\n▸ ${P}weather <city> — Weather info\n` +
      `▸ ${P}news [topic] — Latest news\n▸ ${P}translate <lang> <text> — Translate\n` +
      `▸ ${P}time <timezone> — World time\n▸ ${P}currency <amount> <from> <to> — Convert\n` +
      `▸ ${P}shorturl <url> — Shorten URL\n▸ ${P}qr <text> — Generate QR code\n` +
      `▸ ${P}reminder <time> <msg> — Set reminder\n▸ ${P}myreminders — View reminders\n` +
      `▸ ${P}todo add <task> — Add todo\n▸ ${P}todo list — View todos\n` +
      `▸ ${P}afk [reason] — Go AFK\n▸ ${P}profile — View your profile\n` +
      `▸ ${P}info — Group/Chat info\n▸ ${P}whois @user — User info`);
  },
};

// ─── PING ─────────────────────────────────────────────────────────────────
const ping = {
  description: 'Check bot response time',
  aliases: ['speed', 'latency'],
  async execute(ctx) {
    const start = Date.now();
    const m = await ctx.reply('🏓 Pinging...');
    const diff = Date.now() - start;
    return ctx.reply(`🏓 *Pong!*\n⚡ Latency: *${diff}ms*\n🤖 Bot: *Online*`);
  },
};

// ─── UPTIME ───────────────────────────────────────────────────────────────
const uptime = {
  description: 'Show bot uptime',
  async execute(ctx) {
    const sec = process.uptime();
    const d = Math.floor(sec / 86400);
    const h = Math.floor((sec % 86400) / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = Math.floor(sec % 60);
    return ctx.reply(`⏱️ *XaviBot Uptime*\n\n${d}d ${h}h ${m}m ${s}s`);
  },
};

// ─── CALCULATOR ───────────────────────────────────────────────────────────
const calc = {
  description: 'Evaluate a math expression',
  usage: '<expression>',
  aliases: ['calculate', 'math', 'eval'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .calc <expression>');
    try {
      const result = math.evaluate(ctx.query);
      return ctx.reply(`🧮 *Calculator*\n\n📥 Input: \`${ctx.query}\`\n📤 Result: *${result}*`);
    } catch (e) {
      return ctx.reply(`❌ Invalid expression: ${e.message}`);
    }
  },
};

// ─── WEATHER ──────────────────────────────────────────────────────────────
const weather = {
  description: 'Get weather for a city',
  usage: '<city>',
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .weather <city>');
    const key = process.env.WEATHER_API_KEY;
    if (!key) return ctx.reply('❌ Weather API key not configured. Add WEATHER_API_KEY to .env');
    try {
      const { data } = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(ctx.query)}&appid=${key}&units=metric`
      );
      const { main, weather: w, wind, name, sys } = data;
      return ctx.reply(
        `🌤️ *Weather in ${name}, ${sys.country}*\n\n` +
        `🌡️ Temp: ${main.temp}°C (feels ${main.feels_like}°C)\n` +
        `💧 Humidity: ${main.humidity}%\n` +
        `🌬️ Wind: ${wind.speed} m/s\n` +
        `☁️ Condition: ${w[0].description}\n` +
        `📈 Max: ${main.temp_max}°C | Min: ${main.temp_min}°C`
      );
    } catch (e) {
      return ctx.reply(`❌ City not found or API error.`);
    }
  },
};

// ─── CURRENCY ─────────────────────────────────────────────────────────────
const currency = {
  description: 'Convert between currencies',
  usage: '<amount> <from> <to>',
  aliases: ['convert', 'fx'],
  async execute(ctx) {
    const [amount, from, to] = ctx.args;
    if (!amount || !from || !to) return ctx.reply('❌ Usage: .currency 100 USD NGN');
    try {
      const { data } = await axios.get(`https://api.exchangerate-api.com/v4/latest/${from.toUpperCase()}`);
      const rate = data.rates[to.toUpperCase()];
      if (!rate) return ctx.reply('❌ Invalid currency code');
      const result = (parseFloat(amount) * rate).toFixed(2);
      return ctx.reply(`💱 *Currency Converter*\n\n${amount} ${from.toUpperCase()} = *${result} ${to.toUpperCase()}*\nRate: 1 ${from.toUpperCase()} = ${rate} ${to.toUpperCase()}`);
    } catch (e) {
      return ctx.reply('❌ Conversion failed. Check currency codes.');
    }
  },
};

// ─── TIME ─────────────────────────────────────────────────────────────────
const time = {
  description: 'Get current time in a timezone',
  usage: '<timezone>',
  aliases: ['clock'],
  async execute(ctx) {
    const tz = ctx.query || 'UTC';
    try {
      const now = new Date().toLocaleString('en-US', { timeZone: tz, dateStyle: 'full', timeStyle: 'long' });
      return ctx.reply(`🕐 *Time in ${tz}*\n${now}`);
    } catch (e) {
      return ctx.reply('❌ Invalid timezone. Example: .time Africa/Lagos');
    }
  },
};

// ─── QR CODE ──────────────────────────────────────────────────────────────
const qr = {
  description: 'Generate a QR code',
  usage: '<text>',
  aliases: ['qrcode'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .qr <text or url>');
    const url = `https://api.qrserver.com/v1/create-qr-code/?size=512x512&data=${encodeURIComponent(ctx.query)}`;
    try {
      const { data } = await axios.get(url, { responseType: 'arraybuffer' });
      return ctx.replyMedia('image', Buffer.from(data), `QR Code for: ${ctx.query}`);
    } catch (e) {
      return ctx.reply('❌ Failed to generate QR code.');
    }
  },
};

// ─── PROFILE ──────────────────────────────────────────────────────────────
const profile = {
  description: 'View your bot profile',
  aliases: ['me', 'stat'],
  async execute(ctx) {
    const user = Users.get.get(ctx.senderJid, ctx.sessionId);
    if (!user) return ctx.reply('❌ Profile not found.');
    const level = Math.floor((user.xp || 0) / 100) + 1;
    return ctx.reply(
      `👤 *Your XaviBot Profile*\n\n` +
      `📛 Name: ${user.name || ctx.pushName}\n` +
      `📱 Number: ${ctx.senderNumber}\n` +
      `💬 Messages: ${user.message_count}\n` +
      `⭐ XP: ${user.xp || 0}\n` +
      `🏆 Level: ${level}\n` +
      `💰 Coins: ${user.coins || 0}\n` +
      `👑 Premium: ${user.is_premium ? 'Yes ✅' : 'No ❌'}\n` +
      `⚠️ Warnings: ${user.warnings || 0}`
    );
  },
};

// ─── WHOIS ────────────────────────────────────────────────────────────────
const whois = {
  description: 'View info about a user',
  usage: '@user',
  aliases: ['userinfo', 'uinfo'],
  groupOnly: true,
  async execute(ctx) {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
    const target = mentioned?.[0] || ctx.senderJid;
    const user = Users.get.get(target, ctx.sessionId);
    const number = target.replace('@s.whatsapp.net', '');
    return ctx.reply(
      `👤 *User Info*\n\n` +
      `📱 Number: ${number}\n` +
      `💬 Messages: ${user?.message_count || 0}\n` +
      `⭐ XP: ${user?.xp || 0}\n` +
      `💰 Coins: ${user?.coins || 0}\n` +
      `👑 Premium: ${user?.is_premium ? 'Yes' : 'No'}\n` +
      `⚠️ Warnings: ${user?.warnings || 0}\n` +
      `🚫 Banned: ${user?.is_banned ? 'Yes' : 'No'}`
    );
  },
};

// ─── INFO ─────────────────────────────────────────────────────────────────
const info = {
  description: 'View group or chat info',
  aliases: ['groupinfo', 'chatinfo'],
  async execute(ctx) {
    if (ctx.isGroup) {
      const meta = ctx.groupMeta;
      const admins = meta.participants.filter(p => p.admin).length;
      return ctx.reply(
        `👥 *Group Info*\n\n` +
        `📛 Name: ${meta.subject}\n` +
        `🆔 JID: ${meta.id}\n` +
        `👤 Members: ${meta.participants.length}\n` +
        `🛡️ Admins: ${admins}\n` +
        `📝 Description: ${meta.desc || 'None'}\n` +
        `📅 Created: ${new Date(meta.creation * 1000).toLocaleDateString()}`
      );
    }
    return ctx.reply(
      `💬 *Private Chat*\n\n` +
      `📱 Number: ${ctx.senderNumber}\n` +
      `👤 Name: ${ctx.pushName}\n` +
      `🤖 Bot: XaviBot\n` +
      `🔗 Session: ${ctx.sessionId.slice(0, 8)}...`
    );
  },
};

// ─── REMINDER ─────────────────────────────────────────────────────────────
const reminder = {
  description: 'Set a reminder',
  usage: '<time> <message> (e.g. .reminder 30m Call mom)',
  aliases: ['remind', 'remindme'],
  async execute(ctx) {
    const [timeStr, ...msgParts] = ctx.args;
    if (!timeStr || !msgParts.length) return ctx.reply('❌ Usage: .reminder 30m Call mom');
    const ms = parseTime(timeStr);
    if (!ms) return ctx.reply('❌ Invalid time. Use: 30s, 5m, 2h, 1d');
    const message = msgParts.join(' ');
    const remindAt = new Date(Date.now() + ms).toISOString().replace('T', ' ').slice(0, 19);
    Reminders.add.run(ctx.sessionId, ctx.senderJid, ctx.remoteJid, message, remindAt);
    return ctx.reply(`✅ Reminder set for *${timeStr}* from now!\n📝 Message: ${message}`);
  },
};

const myreminders = {
  description: 'View your pending reminders',
  aliases: ['reminders'],
  async execute(ctx) {
    const list = Reminders.getUserReminders.all(ctx.senderJid, ctx.sessionId);
    if (!list.length) return ctx.reply('📭 You have no pending reminders.');
    const text = list.map((r, i) => `${i + 1}. ⏰ ${r.remind_at}\n   📝 ${r.message}`).join('\n\n');
    return ctx.reply(`⏰ *Your Reminders*\n\n${text}`);
  },
};

// ─── TODO ─────────────────────────────────────────────────────────────────
const todo = {
  description: 'Manage your todo list',
  usage: 'add|list|done|delete|clear',
  async execute(ctx) {
    const [sub, ...rest] = ctx.args;
    const task = rest.join(' ');

    if (!sub || sub === 'list') {
      const todos = Todos.getAll.all(ctx.senderJid, ctx.sessionId);
      if (!todos.length) return ctx.reply('📭 Your todo list is empty! Add with .todo add <task>');
      const text = todos.map((t, i) => `${i + 1}. ☐ ${t.task}`).join('\n');
      return ctx.reply(`📋 *Your Todo List*\n\n${text}`);
    }

    if (sub === 'add') {
      if (!task) return ctx.reply('❌ Usage: .todo add <task>');
      Todos.add.run(ctx.senderJid, ctx.sessionId, task);
      return ctx.reply(`✅ Added: *${task}*`);
    }

    if (sub === 'done') {
      const id = parseInt(rest[0]);
      const todos = Todos.getAll.all(ctx.senderJid, ctx.sessionId);
      const t = todos[id - 1];
      if (!t) return ctx.reply('❌ Invalid todo number.');
      Todos.done.run(t.id, ctx.senderJid);
      return ctx.reply(`✅ Marked as done: *${t.task}*`);
    }

    if (sub === 'delete') {
      const id = parseInt(rest[0]);
      const todos = Todos.getAll.all(ctx.senderJid, ctx.sessionId);
      const t = todos[id - 1];
      if (!t) return ctx.reply('❌ Invalid todo number.');
      Todos.delete.run(t.id, ctx.senderJid);
      return ctx.reply(`🗑️ Deleted: *${t.task}*`);
    }

    if (sub === 'clear') {
      Todos.clear.run(ctx.senderJid, ctx.sessionId);
      return ctx.reply('🗑️ Todo list cleared!');
    }
  },
};

// ─── AFK ──────────────────────────────────────────────────────────────────
const afk = {
  description: 'Set yourself as AFK',
  usage: '[reason]',
  async execute(ctx) {
    const reason = ctx.query || 'AFK';
    Afk.set.run(ctx.senderJid, ctx.sessionId, reason);
    return ctx.reply(`💤 You are now AFK\nReason: *${reason}*`);
  },
};

// ─── SHORTURL ─────────────────────────────────────────────────────────────
const shorturl = {
  description: 'Shorten a URL',
  usage: '<url>',
  aliases: ['shorten', 'short'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .shorturl <url>');
    try {
      const { data } = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(ctx.query)}`);
      return ctx.reply(`🔗 *URL Shortened!*\n\nOriginal: ${ctx.query}\nShort: *${data}*`);
    } catch (e) {
      return ctx.reply('❌ Failed to shorten URL.');
    }
  },
};

// ─── DEFINE ───────────────────────────────────────────────────────────────
const define = {
  description: 'Get definition of a word',
  usage: '<word>',
  aliases: ['dict', 'dictionary', 'meaning'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .define <word>');
    try {
      const { data } = await axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${ctx.query}`);
      const entry = data[0];
      const meanings = entry.meanings.slice(0, 2).map(m =>
        `*${m.partOfSpeech}*\n${m.definitions.slice(0, 2).map((d, i) => `${i + 1}. ${d.definition}`).join('\n')}`
      ).join('\n\n');
      return ctx.reply(`📖 *${entry.word}*\n\n${meanings}`);
    } catch (e) {
      return ctx.reply(`❌ Word not found.`);
    }
  },
};

// ─── SYNONYM ──────────────────────────────────────────────────────────────
const synonym = {
  description: 'Get synonyms of a word',
  usage: '<word>',
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .synonym <word>');
    try {
      const { data } = await axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${ctx.query}`);
      const syns = data[0].meanings.flatMap(m => m.synonyms).slice(0, 10);
      if (!syns.length) return ctx.reply(`❌ No synonyms found for *${ctx.query}*`);
      return ctx.reply(`📝 *Synonyms for ${ctx.query}:*\n\n${syns.join(', ')}`);
    } catch (e) {
      return ctx.reply('❌ Word not found.');
    }
  },
};

// ─── ANTONYM ──────────────────────────────────────────────────────────────
const antonym = {
  description: 'Get antonyms of a word',
  usage: '<word>',
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .antonym <word>');
    try {
      const { data } = await axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${ctx.query}`);
      const ants = data[0].meanings.flatMap(m => m.antonyms).slice(0, 10);
      if (!ants.length) return ctx.reply(`❌ No antonyms found for *${ctx.query}*`);
      return ctx.reply(`📝 *Antonyms for ${ctx.query}:*\n\n${ants.join(', ')}`);
    } catch (e) {
      return ctx.reply('❌ Word not found.');
    }
  },
};

// ─── FACT ─────────────────────────────────────────────────────────────────
const fact = {
  description: 'Get a random fact',
  aliases: ['randomfact', 'funfact'],
  async execute(ctx) {
    try {
      const { data } = await axios.get('https://uselessfacts.jsph.pl/random.json?language=en');
      return ctx.reply(`💡 *Random Fact*\n\n${data.text}`);
    } catch (e) {
      const facts = [
        'Honey never spoils. Archaeologists have found 3000-year-old honey in Egyptian tombs.',
        'A group of flamingos is called a "flamboyance".',
        'Cleopatra lived closer in time to the Moon landing than to the construction of the Great Pyramid.',
        'Bananas are berries, but strawberries are not.',
        'The shortest war in history lasted 38 to 45 minutes.'
      ];
      return ctx.reply(`💡 *Random Fact*\n\n${randomChoice(facts)}`);
    }
  },
};

// ─── TRIVIA ───────────────────────────────────────────────────────────────
const trivia = {
  description: 'Get a trivia question',
  aliases: ['quiz'],
  async execute(ctx) {
    try {
      const { data } = await axios.get('https://opentdb.com/api.php?amount=1&type=multiple');
      const q = data.results[0];
      const allAnswers = [...q.incorrect_answers, q.correct_answer].sort(() => Math.random() - 0.5);
      const options = allAnswers.map((a, i) => `${['A', 'B', 'C', 'D'][i]}. ${a}`).join('\n');
      return ctx.reply(
        `❓ *Trivia*\n\n*Category:* ${q.category}\n*Difficulty:* ${q.difficulty}\n\n*${q.question}*\n\n${options}\n\n_Reply .answer A/B/C/D_`
      );
    } catch (e) {
      return ctx.reply('❌ Failed to fetch trivia. Try again!');
    }
  },
};

// ─── QUOTE ────────────────────────────────────────────────────────────────
const quote = {
  description: 'Get an inspirational quote',
  aliases: ['inspire', 'motivation', 'qod'],
  async execute(ctx) {
    try {
      const { data } = await axios.get('https://zenquotes.io/api/random');
      const q = data[0];
      return ctx.reply(`💬 *Quote of the Moment*\n\n"${q.q}"\n\n— _${q.a}_`);
    } catch (e) {
      const quotes = [
        '"Success is not final, failure is not fatal: it is the courage to continue that counts." — Winston Churchill',
        '"The only way to do great work is to love what you do." — Steve Jobs',
        '"In the middle of every difficulty lies opportunity." — Albert Einstein',
      ];
      return ctx.reply(`💬 *Quote*\n\n${randomChoice(quotes)}`);
    }
  },
};

// ─── HOROSCOPE ────────────────────────────────────────────────────────────
const horoscope = {
  description: 'Get your daily horoscope',
  usage: '<sign>',
  async execute(ctx) {
    const signs = ['aries','taurus','gemini','cancer','leo','virgo','libra','scorpio','sagittarius','capricorn','aquarius','pisces'];
    const sign = ctx.args[0]?.toLowerCase();
    if (!sign || !signs.includes(sign)) {
      return ctx.reply(`❌ Usage: .horoscope <sign>\nSigns: ${signs.join(', ')}`);
    }
    try {
      const { data } = await axios.get(`https://horoscope-app-api.vercel.app/api/v1/get-horoscope/daily?sign=${sign}&day=today`);
      return ctx.reply(`♈ *${sign.toUpperCase()} Horoscope*\n\n${data.data.horoscope_data}`);
    } catch (e) {
      return ctx.reply('❌ Failed to fetch horoscope. Try again!');
    }
  },
};

// ─── NEWS ─────────────────────────────────────────────────────────────────
const news = {
  description: 'Get latest news',
  usage: '[topic]',
  async execute(ctx) {
    const key = process.env.NEWS_API_KEY;
    if (!key) return ctx.reply('❌ News API key not configured. Add NEWS_API_KEY to .env');
    const topic = ctx.query || 'world';
    try {
      const { data } = await axios.get(
        `https://newsapi.org/v2/top-headlines?q=${topic}&apiKey=${key}&pageSize=5&language=en`
      );
      if (!data.articles.length) return ctx.reply('❌ No news found for that topic.');
      const text = data.articles.slice(0, 5).map((a, i) =>
        `${i + 1}. *${a.title}*\n   ${a.source.name} • ${new Date(a.publishedAt).toLocaleDateString()}`
      ).join('\n\n');
      return ctx.reply(`📰 *News: ${topic}*\n\n${text}`);
    } catch (e) {
      return ctx.reply('❌ Failed to fetch news.');
    }
  },
};

// ─── JOKE ─────────────────────────────────────────────────────────────────
const joke = {
  description: 'Get a random joke',
  aliases: ['lol', 'funny'],
  async execute(ctx) {
    try {
      const { data } = await axios.get('https://v2.jokeapi.dev/joke/Any?blacklistFlags=nsfw,racist&type=twopart');
      return ctx.reply(`😂 *Joke Time!*\n\n${data.setup}\n\n||${data.delivery}||`);
    } catch (e) {
      const jokes = [
        'Why do programmers prefer dark mode?\nBecause light attracts bugs! 🐛',
        'How do you comfort a JavaScript bug?\nYou console it! 🖥️',
        'Why did the scarecrow win an award?\nBecause he was outstanding in his field! 🌾',
      ];
      return ctx.reply(`😂 *Joke Time!*\n\n${randomChoice(jokes)}`);
    }
  },
};

// ─── RIDDLE ───────────────────────────────────────────────────────────────
const riddle = {
  description: 'Get a brain teaser riddle',
  async execute(ctx) {
    const riddles = [
      { q: 'I speak without a mouth and hear without ears. I have no body, but I come alive with the wind. What am I?', a: 'An echo' },
      { q: 'The more you take, the more you leave behind. What am I?', a: 'Footsteps' },
      { q: 'I have cities but no houses, mountains but no trees, water but no fish, and roads but no cars. What am I?', a: 'A map' },
      { q: "What can you catch but not throw?", a: 'A cold' },
      { q: 'What gets wetter the more it dries?', a: 'A towel' },
    ];
    const r = randomChoice(riddles);
    await ctx.reply(`🤔 *Brain Teaser*\n\n${r.q}\n\n_Reply .answer to reveal the answer_`);
    // Store for this chat temporarily
    ctx.sock._riddleAnswers = ctx.sock._riddleAnswers || {};
    ctx.sock._riddleAnswers[ctx.remoteJid] = r.a;
  },
};

const answer = {
  description: 'Reveal answer to riddle/trivia',
  async execute(ctx) {
    const ans = ctx.sock._riddleAnswers?.[ctx.remoteJid];
    if (!ans) return ctx.reply('❌ No active riddle/trivia. Use .riddle or .trivia first!');
    delete ctx.sock._riddleAnswers[ctx.remoteJid];
    return ctx.reply(`💡 *Answer:* ${ans}`);
  },
};

// ─── TRANSLATE ────────────────────────────────────────────────────────────
const translate = {
  description: 'Translate text to another language',
  usage: '<language> <text>',
  aliases: ['tr'],
  async execute(ctx) {
    const [lang, ...rest] = ctx.args;
    if (!lang || !rest.length) return ctx.reply('❌ Usage: .translate es Hello world');
    try {
      const { data } = await axios.get(
        `https://api.mymemory.translated.net/get?q=${encodeURIComponent(rest.join(' '))}&langpair=en|${lang}`
      );
      return ctx.reply(`🌐 *Translation (${lang})*\n\n${data.responseData.translatedText}`);
    } catch (e) {
      return ctx.reply('❌ Translation failed.');
    }
  },
};

module.exports = {
  help, aihelp, mediahelp, grouphelp, funhelp, utilityhelp,
  ping, uptime, calc, weather, currency, time, qr,
  profile, whois, info, reminder, myreminders, todo, afk,
  shorturl, define, synonym, antonym, fact, trivia, quote,
  horoscope, news, joke, riddle, answer, translate,
};
