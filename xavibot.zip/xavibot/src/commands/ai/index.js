const axios = require('axios');
const { randomChoice } = require('../../utils/helpers');

// ─── AI CHAT (Gemini or OpenAI fallback) ─────────────────────────────────
const ai = {
  description: 'Ask the AI anything',
  usage: '<question>',
  aliases: ['gpt', 'ask', 'chat', 'claude', 'bot'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .ai <your question>');
    await ctx.react('🤔');

    // Try Gemini first
    const geminiKey = process.env.GEMINI_API_KEY;
    const openaiKey = process.env.OPENAI_API_KEY;

    if (geminiKey) {
      try {
        const { data } = await axios.post(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${geminiKey}`,
          { contents: [{ parts: [{ text: ctx.query }] }] }
        );
        const text = data.candidates[0].content.parts[0].text;
        return ctx.reply(`🤖 *XaviBot AI*\n\n${text}`);
      } catch (e) {
        console.error('Gemini error:', e.message);
      }
    }

    if (openaiKey) {
      try {
        const { data } = await axios.post(
          'https://api.openai.com/v1/chat/completions',
          {
            model: 'gpt-3.5-turbo',
            messages: [
              { role: 'system', content: 'You are XaviBot, a helpful WhatsApp assistant. Be concise and friendly.' },
              { role: 'user', content: ctx.query }
            ],
            max_tokens: 500,
          },
          { headers: { Authorization: `Bearer ${openaiKey}` } }
        );
        return ctx.reply(`🤖 *XaviBot AI*\n\n${data.choices[0].message.content}`);
      } catch (e) {
        console.error('OpenAI error:', e.message);
      }
    }

    // Fallback - free API
    try {
      const { data } = await axios.get(
        `https://api.paxsenix.biz.id/ai/gpt4?text=${encodeURIComponent(ctx.query)}`
      );
      const result = data.message || data.result || data.response;
      if (result) return ctx.reply(`🤖 *XaviBot AI*\n\n${result}`);
    } catch (_) {}

    return ctx.reply('❌ AI is not configured. Add GEMINI_API_KEY or OPENAI_API_KEY to your .env file.');
  },
};

// ─── SUMMARIZE ────────────────────────────────────────────────────────────
const summarize = {
  description: 'Summarize a long text',
  usage: '<text>',
  aliases: ['summary', 'tldr'],
  async execute(ctx) {
    if (!ctx.query || ctx.query.split(' ').length < 10) {
      return ctx.reply('❌ Please provide a longer text to summarize. Usage: .summarize <long text>');
    }
    const prompt = `Summarize the following text in 3-5 bullet points:\n\n${ctx.query}`;
    return ai.execute({ ...ctx, query: prompt });
  },
};

// ─── REWRITE ──────────────────────────────────────────────────────────────
const rewrite = {
  description: 'Rewrite text to make it better',
  usage: '<text>',
  aliases: ['improve', 'paraphrase'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .rewrite <text>');
    const prompt = `Rewrite and improve this text while keeping the same meaning:\n\n${ctx.query}`;
    return ai.execute({ ...ctx, query: prompt });
  },
};

// ─── GRAMMAR ──────────────────────────────────────────────────────────────
const grammar = {
  description: 'Fix grammar in text',
  usage: '<text>',
  aliases: ['fix', 'correct', 'spellcheck'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .grammar <text>');
    const prompt = `Fix all grammar, spelling and punctuation errors in this text and return only the corrected version:\n\n${ctx.query}`;
    return ai.execute({ ...ctx, query: prompt });
  },
};

// ─── ROAST ────────────────────────────────────────────────────────────────
const roast = {
  description: 'Roast a user with a funny insult',
  usage: '@user or name',
  async execute(ctx) {
    const name = ctx.args.join(' ') || ctx.pushName;
    const roasts = [
      `${name} is so slow, they'd lose a race to a parked car. 😭`,
      `If brains were gasoline, ${name} couldn't power an ant's motorcycle around a cheerio. 🐜`,
      `${name} is the human equivalent of a participation trophy. 🏅`,
      `${name} is proof that even WiFi can connect with anyone — no matter how weak the signal. 📶`,
      `${name}'s search history is just "how to be interesting" on repeat. 💀`,
      `${name} has the personality of wet cardboard and the charisma of a spreadsheet. 📊`,
      `${name} is like a software update — nobody wants them but they keep showing up anyway. 🔄`,
    ];
    return ctx.reply(`🔥 *Roast for ${name}*\n\n${randomChoice(roasts)}`);
  },
};

// ─── COMPLIMENT ───────────────────────────────────────────────────────────
const compliment = {
  description: 'Give a compliment to someone',
  usage: '@user or name',
  async execute(ctx) {
    const name = ctx.args.join(' ') || ctx.pushName;
    const compliments = [
      `${name}, you make the world brighter just by being in it! ✨`,
      `${name} is the kind of person who makes everyone feel welcome and important. 🌟`,
      `${name}'s dedication and hard work is truly inspiring! 💪`,
      `${name} has a heart of gold and a smile that can light up any room! 😊`,
      `Being around ${name} is like finding money in an old jacket — unexpected and wonderful! 💰`,
      `${name} is proof that some people are just naturally awesome! 🚀`,
    ];
    return ctx.reply(`💝 *Compliment for ${name}*\n\n${randomChoice(compliments)}`);
  },
};

// ─── IMAGINE ──────────────────────────────────────────────────────────────
const imagine = {
  description: 'Generate an AI image',
  usage: '<prompt>',
  aliases: ['generate', 'draw', 'genimage'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .imagine <describe the image you want>');
    await ctx.reply('🎨 Generating image... Please wait!');
    try {
      // Pollinations AI - free image generation
      const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(ctx.query)}?width=512&height=512&nologo=true`;
      const { data } = await axios.get(url, { responseType: 'arraybuffer', timeout: 30000 });
      return ctx.replyMedia('image', Buffer.from(data), `🎨 "${ctx.query}"\n_Generated by XaviBot AI_`);
    } catch (e) {
      return ctx.reply('❌ Image generation failed. Try a different prompt!');
    }
  },
};

// ─── SENTIMENT ────────────────────────────────────────────────────────────
const sentiment = {
  description: 'Analyze the sentiment of a text',
  usage: '<text>',
  aliases: ['mood', 'feeling'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .sentiment <text>');
    const prompt = `Analyze the sentiment of this text and respond with: Sentiment (Positive/Negative/Neutral), Confidence (%), Key emotions detected, and a brief explanation:\n\n"${ctx.query}"`;
    return ai.execute({ ...ctx, query: prompt });
  },
};

// ─── ESSAY ────────────────────────────────────────────────────────────────
const essay = {
  description: 'Write a short essay on any topic',
  usage: '<topic>',
  aliases: ['write', 'article'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .essay <topic>');
    const prompt = `Write a well-structured short essay (3 paragraphs) about: ${ctx.query}`;
    return ai.execute({ ...ctx, query: prompt });
  },
};

// ─── RECIPE ───────────────────────────────────────────────────────────────
const recipe = {
  description: 'Get a recipe for any dish',
  usage: '<dish name>',
  aliases: ['cook', 'food'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .recipe <dish name>');
    const prompt = `Give me a detailed recipe for ${ctx.query} with ingredients list and step-by-step cooking instructions. Keep it concise.`;
    return ai.execute({ ...ctx, query: prompt });
  },
};

// ─── ADVICE ───────────────────────────────────────────────────────────────
const advice = {
  description: 'Get life advice on any topic',
  usage: '<situation>',
  aliases: ['counsel'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .advice <your situation>');
    const prompt = `Give kind, practical advice for this situation: ${ctx.query}. Be supportive and constructive.`;
    return ai.execute({ ...ctx, query: prompt });
  },
};

// ─── STORY ────────────────────────────────────────────────────────────────
const story = {
  description: 'Generate a short story',
  usage: '<theme or characters>',
  aliases: ['tale'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .story <theme>');
    const prompt = `Write a very short engaging story (150-200 words) about: ${ctx.query}`;
    return ai.execute({ ...ctx, query: prompt });
  },
};

// ─── POEM ─────────────────────────────────────────────────────────────────
const poem = {
  description: 'Generate a poem',
  usage: '<topic>',
  aliases: ['poetry'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .poem <topic>');
    const prompt = `Write a beautiful short poem about: ${ctx.query}`;
    return ai.execute({ ...ctx, query: prompt });
  },
};

// ─── CAPTION ──────────────────────────────────────────────────────────────
const caption = {
  description: 'Generate social media captions',
  usage: '<topic or photo description>',
  aliases: ['captions'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Usage: .caption <description>');
    const prompt = `Generate 5 creative and engaging social media captions for: ${ctx.query}. Include relevant emojis and hashtags.`;
    return ai.execute({ ...ctx, query: prompt });
  },
};

// ─── PICKUP ───────────────────────────────────────────────────────────────
const pickup = {
  description: 'Get a pickup line',
  aliases: ['flirt', 'pickupline'],
  async execute(ctx) {
    const lines = [
      "Are you a WiFi signal? Because I'm feeling a connection. 📶",
      "Do you have a map? I keep getting lost in your eyes. 🗺️",
      "Are you a bank loan? Because you have my interest. 💰",
      "Is your name Google? Because you have everything I've been searching for. 🔍",
      "Are you a parking ticket? Because you've got 'fine' written all over you. 🎫",
      "Do you believe in love at first byte? 💾",
      "Are you a camera? Every time I look at you, I smile. 📸",
    ];
    return ctx.reply(`💌 *Pickup Line*\n\n${randomChoice(lines)}`);
  },
};

// ─── MOTIVATION ───────────────────────────────────────────────────────────
const motivation = {
  description: 'Get a motivational message',
  aliases: ['inspire', 'moti'],
  async execute(ctx) {
    const msgs = [
      "💪 Every day is a new chance to improve yourself. Don't compare your chapter 1 to someone else's chapter 20!",
      "🚀 The difference between ordinary and extraordinary is that little EXTRA. Keep pushing!",
      "⭐ You are capable of amazing things. Believe in yourself and take that first step!",
      "🔥 Success is not given, it's earned. Grind now, shine later!",
      "🌟 Your only competition is the person you were yesterday. Keep growing!",
    ];
    return ctx.reply(randomChoice(msgs));
  },
};

module.exports = {
  ai, summarize, rewrite, grammar, roast, compliment,
  imagine, sentiment, essay, recipe, advice, story,
  poem, caption, pickup, motivation,
};
