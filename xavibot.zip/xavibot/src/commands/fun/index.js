const { Economy, Marriage, Users } = require('../../database/db');
const { randomInt, randomChoice } = require('../../utils/helpers');

// ─── 8BALL ────────────────────────────────────────────────────────────────
const eightball = {
  description: 'Ask the magic 8-ball a yes/no question',
  usage: '<question>',
  aliases: ['8ball', 'magic8'],
  async execute(ctx) {
    if (!ctx.query) return ctx.reply('❌ Ask me a question! Usage: .8ball Will I be rich?');
    const answers = [
      '✅ It is certain.', '✅ Without a doubt.', '✅ Yes, definitely!',
      '✅ You may rely on it.', '✅ Most likely.', '🤔 Reply hazy, try again.',
      '🤔 Ask again later.', '🤔 Cannot predict now.', '❌ Don\'t count on it.',
      '❌ My reply is no.', '❌ Very doubtful.', '❌ Outlook not so good.',
    ];
    return ctx.reply(`🎱 *Magic 8-Ball*\n\n❓ ${ctx.query}\n\n${randomChoice(answers)}`);
  },
};

// ─── ROLL ─────────────────────────────────────────────────────────────────
const roll = {
  description: 'Roll a dice',
  usage: '[sides]',
  aliases: ['dice'],
  async execute(ctx) {
    const sides = parseInt(ctx.args[0]) || 6;
    if (sides < 2 || sides > 100) return ctx.reply('❌ Dice must have between 2 and 100 sides.');
    const result = randomInt(1, sides);
    return ctx.reply(`🎲 *Dice Roll (d${sides})*\n\nYou rolled: *${result}*`);
  },
};

// ─── FLIP ─────────────────────────────────────────────────────────────────
const flip = {
  description: 'Flip a coin',
  aliases: ['coin', 'coinflip'],
  async execute(ctx) {
    const result = Math.random() < 0.5 ? 'Heads 🪙' : 'Tails 🌟';
    return ctx.reply(`🪙 *Coin Flip*\n\nResult: *${result}*`);
  },
};

// ─── RPS ──────────────────────────────────────────────────────────────────
const rps = {
  description: 'Play Rock, Paper, Scissors',
  usage: '<rock|paper|scissors>',
  async execute(ctx) {
    const choices = ['rock', 'paper', 'scissors'];
    const emojis = { rock: '🪨', paper: '📄', scissors: '✂️' };
    const player = ctx.args[0]?.toLowerCase();
    if (!choices.includes(player)) return ctx.reply('❌ Choose: rock, paper, or scissors\nUsage: .rps rock');
    const bot = randomChoice(choices);
    let result;
    if (player === bot) result = "It's a *tie*! 🤝";
    else if ((player === 'rock' && bot === 'scissors') || (player === 'paper' && bot === 'rock') || (player === 'scissors' && bot === 'paper')) {
      result = '*You win!* 🎉';
    } else {
      result = '*Bot wins!* 🤖';
    }
    return ctx.reply(`✂️ *Rock Paper Scissors*\n\nYou: ${emojis[player]} ${player}\nBot: ${emojis[bot]} ${bot}\n\n${result}`);
  },
};

// ─── TRUTH ────────────────────────────────────────────────────────────────
const truth = {
  description: 'Get a random truth question',
  async execute(ctx) {
    const truths = [
      "What's the most embarrassing thing you've ever done?",
      "Have you ever lied to get out of trouble? What did you say?",
      "What's your biggest secret that you've never told anyone?",
      "Who was your first crush? Do they know?",
      "What's the weirdest dream you've ever had?",
      "Have you ever cheated on a test or exam?",
      "What's the most childish thing you still do?",
      "Have you ever had a crush on a friend's partner?",
      "What is something you're most afraid of?",
    ];
    return ctx.reply(`💯 *Truth Question*\n\n${randomChoice(truths)}`);
  },
};

// ─── DARE ─────────────────────────────────────────────────────────────────
const dare = {
  description: 'Get a random dare',
  async execute(ctx) {
    const dares = [
      "Send a selfie with the most ridiculous face you can make.",
      "Text someone random from your contacts 'I love you' and show the reply.",
      "Do 10 push-ups right now and send proof.",
      "Change your profile picture to a potato for 1 hour.",
      "Send a voice note singing your favorite song.",
      "Write 'I love XaviBot' and send it to your best friend.",
      "Post an embarrassing childhood photo in this group.",
    ];
    return ctx.reply(`🎯 *Dare!*\n\n${randomChoice(dares)}`);
  },
};

// ─── WOULD YOU RATHER ─────────────────────────────────────────────────────
const wyr = {
  description: 'Would you rather question',
  aliases: ['wouldyourather'],
  async execute(ctx) {
    const questions = [
      ["Have unlimited money but no friends", "Have lots of friends but no money"],
      ["Be able to fly", "Be able to teleport"],
      ["Know when you'll die", "Know how you'll die"],
      ["Live without music", "Live without movies"],
      ["Be famous but hated", "Be unknown but loved"],
      ["Speak all languages", "Talk to animals"],
    ];
    const q = randomChoice(questions);
    return ctx.reply(`🤔 *Would You Rather?*\n\n🅰️ ${q[0]}\n\n*OR*\n\n🅱️ ${q[1]}`);
  },
};

// ─── SHIP ─────────────────────────────────────────────────────────────────
const ship = {
  description: 'Ship two people together',
  usage: '@user1 @user2',
  async execute(ctx) {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (mentioned.length < 2) return ctx.reply('❌ Mention two users! Usage: .ship @user1 @user2');
    const [u1, u2] = mentioned;
    const n1 = u1.replace('@s.whatsapp.net', '');
    const n2 = u2.replace('@s.whatsapp.net', '');
    const score = randomInt(1, 100);
    const bar = '❤️'.repeat(Math.floor(score / 10)) + '🖤'.repeat(10 - Math.floor(score / 10));
    const msg = score >= 80 ? 'Perfect match! 💕' : score >= 60 ? 'Great chemistry! 💞' : score >= 40 ? 'There\'s something there... 💝' : 'Hmm, maybe not 😅';
    await ctx.sock.sendMessage(ctx.remoteJid, {
      text: `💘 *Ship Meter*\n\n@${n1} + @${n2}\n\n${bar}\n*${score}%* — ${msg}`,
      mentions: [u1, u2],
    });
  },
};

// ─── ECONOMY COMMANDS ─────────────────────────────────────────────────────
const balance = {
  description: 'Check your coin balance',
  aliases: ['bal', 'wallet', 'coins'],
  async execute(ctx) {
    Economy.init.run(ctx.senderJid, ctx.sessionId);
    const eco = Economy.get.get(ctx.senderJid, ctx.sessionId);
    return ctx.reply(
      `💰 *${ctx.pushName}'s Wallet*\n\n` +
      `👛 Coins: *${eco.coins}*\n` +
      `🏦 Bank: *${eco.bank}*\n` +
      `💎 Total: *${eco.coins + eco.bank}*`
    );
  },
};

const daily = {
  description: 'Claim daily coins reward',
  async execute(ctx) {
    Economy.init.run(ctx.senderJid, ctx.sessionId);
    const eco = Economy.get.get(ctx.senderJid, ctx.sessionId);
    if (eco.last_daily) {
      const next = new Date(new Date(eco.last_daily).getTime() + 24 * 60 * 60 * 1000);
      if (new Date() < next) {
        const remaining = Math.ceil((next - new Date()) / 3600000);
        return ctx.reply(`⏰ Come back in *${remaining}h* for your daily reward!`);
      }
    }
    const reward = randomInt(100, 500) * (1 + eco.streak);
    Economy.addCoins.run(reward, ctx.senderJid, ctx.sessionId);
    Economy.setDaily.run(ctx.senderJid, ctx.sessionId);
    return ctx.reply(`🎁 *Daily Reward!*\n\n+${reward} coins earned!\n🔥 Streak: ${eco.streak + 1} days\n💰 Balance: ${eco.coins + reward}`);
  },
};

const work = {
  description: 'Work to earn coins',
  async execute(ctx) {
    Economy.init.run(ctx.senderJid, ctx.sessionId);
    const eco = Economy.get.get(ctx.senderJid, ctx.sessionId);
    if (eco.last_work) {
      const next = new Date(new Date(eco.last_work).getTime() + 2 * 60 * 60 * 1000);
      if (new Date() < next) {
        const remaining = Math.ceil((next - new Date()) / 60000);
        return ctx.reply(`⏰ You're tired! Rest for *${remaining} minutes* before working again.`);
      }
    }
    const jobs = ['programmer', 'chef', 'doctor', 'teacher', 'driver', 'farmer', 'trader'];
    const job = randomChoice(jobs);
    const earned = randomInt(50, 200);
    Economy.addCoins.run(earned, ctx.senderJid, ctx.sessionId);
    Economy.setWork.run(ctx.senderJid, ctx.sessionId);
    return ctx.reply(`💼 You worked as a *${job}* and earned *${earned} coins*! 💰`);
  },
};

const crime = {
  description: 'Risk committing a crime for big rewards',
  async execute(ctx) {
    Economy.init.run(ctx.senderJid, ctx.sessionId);
    const eco = Economy.get.get(ctx.senderJid, ctx.sessionId);
    if (eco.last_crime) {
      const next = new Date(new Date(eco.last_crime).getTime() + 4 * 60 * 60 * 1000);
      if (new Date() < next) {
        const remaining = Math.ceil((next - new Date()) / 60000);
        return ctx.reply(`🚓 Lay low for *${remaining} minutes*! Police are watching.`);
      }
    }
    Economy.setCrime.run(ctx.senderJid, ctx.sessionId);
    const success = Math.random() > 0.4;
    if (success) {
      const earned = randomInt(200, 800);
      Economy.addCoins.run(earned, ctx.senderJid, ctx.sessionId);
      const crimes = ['robbed a store', 'hacked a bank', 'picked pockets', 'pulled off a heist'];
      return ctx.reply(`🦹 You *${randomChoice(crimes)}* and got away with *${earned} coins*! 💰`);
    } else {
      const fine = randomInt(50, 300);
      Economy.removeCoins.run(fine, ctx.senderJid, ctx.sessionId);
      return ctx.reply(`🚓 You got caught! Paid *${fine} coins* as a fine! 😅`);
    }
  },
};

const deposit = {
  description: 'Deposit coins to bank',
  usage: '<amount|all>',
  async execute(ctx) {
    Economy.init.run(ctx.senderJid, ctx.sessionId);
    const eco = Economy.get.get(ctx.senderJid, ctx.sessionId);
    const amount = ctx.args[0] === 'all' ? eco.coins : parseInt(ctx.args[0]);
    if (!amount || amount <= 0) return ctx.reply('❌ Usage: .deposit <amount> or .deposit all');
    if (amount > eco.coins) return ctx.reply(`❌ You only have ${eco.coins} coins.`);
    Economy.deposit.run(amount, amount, ctx.senderJid, ctx.sessionId);
    return ctx.reply(`🏦 Deposited *${amount} coins* to your bank!\nBank balance: ${eco.bank + amount}`);
  },
};

const withdraw = {
  description: 'Withdraw coins from bank',
  usage: '<amount|all>',
  async execute(ctx) {
    Economy.init.run(ctx.senderJid, ctx.sessionId);
    const eco = Economy.get.get(ctx.senderJid, ctx.sessionId);
    const amount = ctx.args[0] === 'all' ? eco.bank : parseInt(ctx.args[0]);
    if (!amount || amount <= 0) return ctx.reply('❌ Usage: .withdraw <amount> or .withdraw all');
    if (amount > eco.bank) return ctx.reply(`❌ Your bank only has ${eco.bank} coins.`);
    Economy.withdraw.run(amount, amount, ctx.senderJid, ctx.sessionId);
    return ctx.reply(`💰 Withdrew *${amount} coins* from your bank!\nWallet: ${eco.coins + amount}`);
  },
};

const leaderboard = {
  description: 'View top users by coins',
  aliases: ['lb', 'top', 'richlist'],
  async execute(ctx) {
    const top = Economy.getTop.all(ctx.sessionId);
    if (!top.length) return ctx.reply('📭 No economy data yet!');
    const medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
    const text = top.map((u, i) => {
      const number = u.jid.replace('@s.whatsapp.net', '');
      return `${medals[i]} @${number}: *${u.coins + u.bank}* coins`;
    }).join('\n');
    await ctx.sock.sendMessage(ctx.remoteJid, {
      text: `💰 *Richest Users*\n\n${text}`,
      mentions: top.map(u => u.jid),
    });
  },
};

const give = {
  description: 'Give coins to another user',
  usage: '@user <amount>',
  async execute(ctx) {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!mentioned.length || !ctx.args[1]) return ctx.reply('❌ Usage: .give @user <amount>');
    const target = mentioned[0];
    const amount = parseInt(ctx.args[1]);
    if (!amount || amount <= 0) return ctx.reply('❌ Invalid amount');
    Economy.init.run(ctx.senderJid, ctx.sessionId);
    Economy.init.run(target, ctx.sessionId);
    const eco = Economy.get.get(ctx.senderJid, ctx.sessionId);
    if (amount > eco.coins) return ctx.reply(`❌ You only have ${eco.coins} coins.`);
    Economy.removeCoins.run(amount, ctx.senderJid, ctx.sessionId);
    Economy.addCoins.run(amount, target, ctx.sessionId);
    const number = target.replace('@s.whatsapp.net', '');
    await ctx.sock.sendMessage(ctx.remoteJid, {
      text: `💸 *Transfer Complete!*\n\n${ctx.pushName} sent *${amount} coins* to @${number}!`,
      mentions: [target],
    });
  },
};

// ─── MARRIAGE ─────────────────────────────────────────────────────────────
const marry = {
  description: 'Propose marriage to a user',
  usage: '@user',
  async execute(ctx) {
    const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!mentioned.length) return ctx.reply('❌ Mention someone to propose to. Usage: .marry @user');
    const target = mentioned[0];
    if (target === ctx.senderJid) return ctx.reply('❌ You cannot marry yourself!');
    const existing = Marriage.get.get(ctx.senderJid, ctx.sessionId);
    if (existing?.partner) {
      return ctx.reply(`❌ You are already married! Use .divorce first.`);
    }
    Marriage.set.run(ctx.senderJid, ctx.sessionId, target);
    Marriage.set.run(target, ctx.sessionId, ctx.senderJid);
    const number = target.replace('@s.whatsapp.net', '');
    await ctx.sock.sendMessage(ctx.remoteJid, {
      text: `💍 *Congratulations!*\n\n${ctx.pushName} and @${number} are now married! 👰🤵\n\n💒 May your love last forever!`,
      mentions: [target],
    });
  },
};

const divorce = {
  description: 'Divorce your partner',
  async execute(ctx) {
    const existing = Marriage.get.get(ctx.senderJid, ctx.sessionId);
    if (!existing?.partner) return ctx.reply('❌ You are not married!');
    const partner = existing.partner;
    Marriage.delete.run(ctx.senderJid, ctx.sessionId);
    Marriage.delete.run(partner, ctx.sessionId);
    return ctx.reply(`💔 You have divorced. The marriage is over.\n_It didn't work out..._`);
  },
};

const spouse = {
  description: 'Check your marriage status',
  async execute(ctx) {
    const existing = Marriage.get.get(ctx.senderJid, ctx.sessionId);
    if (!existing?.partner) return ctx.reply('💔 You are not married. Use .marry @user to propose!');
    const number = existing.partner.replace('@s.whatsapp.net', '');
    const since = new Date(existing.married_at).toLocaleDateString();
    return ctx.reply(`💍 *Marriage Status*\n\nMarried to: @${number}\nSince: ${since}`);
  },
};

// ─── LEVEL ────────────────────────────────────────────────────────────────
const level = {
  description: 'Check your XP level',
  aliases: ['xp', 'rank'],
  async execute(ctx) {
    const user = Users.get.get(ctx.senderJid, ctx.sessionId);
    const xp = user?.xp || 0;
    const lvl = Math.floor(xp / 100) + 1;
    const nextLvl = lvl * 100;
    const progress = Math.min(Math.floor((xp % 100) / 100 * 10), 10);
    const bar = '▓'.repeat(progress) + '░'.repeat(10 - progress);
    return ctx.reply(
      `⭐ *${ctx.pushName}'s Level*\n\n` +
      `Level: *${lvl}*\n` +
      `XP: *${xp} / ${nextLvl}*\n` +
      `Progress: [${bar}]\n` +
      `Messages: ${user?.message_count || 0}`
    );
  },
};

// ─── RANDOM NUMBER ────────────────────────────────────────────────────────
const random = {
  description: 'Pick a random number',
  usage: '[min] <max>',
  aliases: ['rand', 'pick', 'number'],
  async execute(ctx) {
    const [a, b] = ctx.args.map(Number);
    const min = b ? a : 1;
    const max = b || a || 100;
    if (isNaN(min) || isNaN(max)) return ctx.reply('❌ Usage: .random 1 100');
    const result = randomInt(min, max);
    return ctx.reply(`🎲 Random number between *${min}* and *${max}*:\n\n*${result}*`);
  },
};

module.exports = {
  eightball, roll, flip, rps, truth, dare, wyr, ship, random,
  balance, daily, work, crime, deposit, withdraw, leaderboard, give,
  marry, divorce, spouse, level,
};
