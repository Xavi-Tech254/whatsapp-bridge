const { Users, Groups, Afk, Logs } = require('../database/db');
const { getPrefix, isOwner, isAdmin, isBanned, extractMessage } = require('../utils/helpers');

// Import all command categories
const aiCommands = require('../commands/ai');
const mediaCommands = require('../commands/media');
const groupCommands = require('../commands/group');
const funCommands = require('../commands/fun');
const utilityCommands = require('../commands/utility');
const ownerCommands = require('../commands/owner');

// Build master command registry
const commandRegistry = new Map();

function registerCommands(commands) {
  for (const [name, handler] of Object.entries(commands)) {
    commandRegistry.set(name.toLowerCase(), handler);
    // Register aliases
    if (handler.aliases) {
      for (const alias of handler.aliases) {
        commandRegistry.set(alias.toLowerCase(), handler);
      }
    }
  }
}

registerCommands(aiCommands);
registerCommands(mediaCommands);
registerCommands(groupCommands);
registerCommands(funCommands);
registerCommands(utilityCommands);
registerCommands(ownerCommands);

async function messageHandler(sock, msg, sessionId, store) {
  try {
    const { key, message, pushName } = msg;
    const { remoteJid, fromMe, participant } = key;

    if (!remoteJid) return;
    if (key.remoteJid === 'status@broadcast') return;

    const isGroup = remoteJid.endsWith('@g.us');
    const senderJid = isGroup ? participant : remoteJid;
    const senderNumber = senderJid?.replace('@s.whatsapp.net', '').replace(/[^0-9]/g, '');

    // Upsert user
    if (senderJid) {
      Users.upsert.run(senderJid, sessionId, pushName || senderNumber);
      Users.incMessages.run(senderJid, sessionId);
    }

    // Upsert group
    if (isGroup) {
      try {
        const groupMeta = await sock.groupMetadata(remoteJid);
        Groups.upsert.run(remoteJid, sessionId, groupMeta.subject);
      } catch (_) {
        Groups.upsert.run(remoteJid, sessionId, 'Unknown Group');
      }
    }

    // Extract message content
    const { body, type, quoted } = extractMessage(message);
    if (!body && !['imageMessage', 'videoMessage', 'audioMessage', 'stickerMessage', 'documentMessage'].includes(type)) return;

    const PREFIX = process.env.BOT_PREFIX || '.';
    const isCmd = body?.startsWith(PREFIX);
    
    // Check AFK - if someone mentions an AFK user
    if (isGroup && body) {
      await checkAfkMention(sock, msg, senderJid, sessionId, body, remoteJid);
    }

    // Remove AFK if user sends a message
    if (senderJid) {
      const afkEntry = Afk.get.get(senderJid, sessionId);
      if (afkEntry) {
        Afk.delete.run(senderJid, sessionId);
        await sock.sendMessage(remoteJid, {
          text: `Welcome back *${pushName}*! 👋\nYou were AFK for: ${getTimeDiff(new Date(afkEntry.since))}`,
        });
      }
    }

    // Check if banned
    if (senderJid) {
      const user = Users.get.get(senderJid, sessionId);
      if (user?.is_banned && !isOwner(senderNumber)) return;
    }

    if (!isCmd) return;

    // Parse command
    const withoutPrefix = body.slice(PREFIX.length).trim();
    const [cmdName, ...args] = withoutPrefix.split(' ');
    const command = cmdName?.toLowerCase();
    if (!command) return;

    // Log command
    Logs.add.run(sessionId, senderJid, remoteJid, command, args.join(' '));

    // Build context object
    const ctx = {
      sock,
      msg,
      key,
      message,
      remoteJid,
      senderJid,
      senderNumber,
      pushName: pushName || senderNumber,
      isGroup,
      isOwner: isOwner(senderNumber),
      isAdmin: false,
      args,
      query: args.join(' '),
      body,
      type,
      quoted,
      sessionId,
      store,
      PREFIX,
      reply: async (text) => sock.sendMessage(remoteJid, { text: String(text) }, { quoted: msg }),
      react: async (emoji) => sock.sendMessage(remoteJid, { react: { text: emoji, key: msg.key } }),
      replyMedia: async (type, data, caption = '') => {
        const payload = { caption };
        payload[type] = data;
        return sock.sendMessage(remoteJid, payload, { quoted: msg });
      },
    };

    // Check admin status for group commands
    if (isGroup) {
      try {
        const groupMeta = await sock.groupMetadata(remoteJid);
        const admins = groupMeta.participants.filter(p => p.admin).map(p => p.id);
        ctx.isAdmin = admins.includes(senderJid);
        ctx.isBotAdmin = admins.includes(sock.user.id) || admins.includes(sock.user.id.replace(':0', ''));
        ctx.groupMeta = groupMeta;
      } catch (_) {}
    }

    // Find and execute command
    const handler = commandRegistry.get(command);

    if (!handler) {
      // Command not found - silent ignore or hint
      return;
    }

    // Permission checks
    if (handler.ownerOnly && !ctx.isOwner) {
      return ctx.reply('❌ This command is for the bot owner only.');
    }
    if (handler.adminOnly && !ctx.isAdmin && !ctx.isOwner) {
      return ctx.reply('❌ This command requires group admin privileges.');
    }
    if (handler.groupOnly && !isGroup) {
      return ctx.reply('❌ This command can only be used in groups.');
    }
    if (handler.privateOnly && isGroup) {
      return ctx.reply('❌ This command can only be used in private chat.');
    }

    // React with processing emoji
    await ctx.react('⏳');

    try {
      await handler.execute(ctx);
      await ctx.react('✅');
    } catch (err) {
      console.error(`Command error [${command}]:`, err);
      await ctx.react('❌');
      await ctx.reply(`❌ Error executing command: ${err.message}`);
    }

  } catch (err) {
    console.error('Message handler error:', err);
  }
}

async function checkAfkMention(sock, msg, senderJid, sessionId, body, remoteJid) {
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
  for (const jid of mentioned) {
    if (jid === senderJid) continue;
    const afkEntry = Afk.get.get(jid, sessionId);
    if (afkEntry) {
      const name = jid.replace('@s.whatsapp.net', '');
      await sock.sendMessage(remoteJid, {
        text: `💤 *${name}* is currently AFK\nReason: ${afkEntry.reason}\nSince: ${getTimeDiff(new Date(afkEntry.since))} ago`,
      });
    }
  }
}

function getTimeDiff(date) {
  const diff = Date.now() - date.getTime();
  const mins = Math.floor(diff / 60000);
  const hrs = Math.floor(mins / 60);
  const days = Math.floor(hrs / 24);
  if (days > 0) return `${days}d ${hrs % 24}h`;
  if (hrs > 0) return `${hrs}h ${mins % 60}m`;
  return `${mins}m`;
}

module.exports = { messageHandler, commandRegistry };
