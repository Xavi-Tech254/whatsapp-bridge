const { Groups, Users } = require('../database/db');

async function groupEventHandler(sock, update, sessionId) {
  const { id, participants, action } = update;

  let groupMeta;
  try {
    groupMeta = await sock.groupMetadata(id);
  } catch (_) {
    return;
  }

  const groupName = groupMeta.subject;
  const group = Groups.get.get(id, sessionId);

  for (const participant of participants) {
    const name = participant.replace('@s.whatsapp.net', '');

    if (action === 'add') {
      Users.upsert.run(participant, sessionId, name);

      if (group?.is_welcome_on) {
        let welcomeMsg = group.welcome_msg || 'Welcome {user} to {group}! 👋';
        welcomeMsg = welcomeMsg
          .replace('{user}', `@${name}`)
          .replace('{group}', groupName)
          .replace('{count}', groupMeta.participants.length);

        await sock.sendMessage(id, {
          text: welcomeMsg,
          mentions: [participant],
        });
      }
    }

    if (action === 'remove') {
      if (group?.is_goodbye_on) {
        let goodbyeMsg = group.goodbye_msg || 'Goodbye {user}! We will miss you 👋';
        goodbyeMsg = goodbyeMsg
          .replace('{user}', `@${name}`)
          .replace('{group}', groupName);

        await sock.sendMessage(id, {
          text: goodbyeMsg,
          mentions: [participant],
        });
      }
    }

    if (action === 'promote') {
      await sock.sendMessage(id, {
        text: `🎉 Congratulations @${name}! You have been promoted to *Admin* 👑`,
        mentions: [participant],
      });
    }

    if (action === 'demote') {
      await sock.sendMessage(id, {
        text: `📉 @${name} has been demoted from admin.`,
        mentions: [participant],
      });
    }
  }
}

module.exports = { groupEventHandler };
