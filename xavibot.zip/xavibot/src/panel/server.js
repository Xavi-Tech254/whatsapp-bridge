const express = require('express');
const { createServer } = require('http');
const { Server } = require('socket.io');
const session = require('express-session');
const path = require('path');
const { createSession, deleteSession, getActiveSessions, setSocketIO } = require('../sessionManager');
const { Sessions, Logs, Users } = require('../database/db');

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: '*' } });

const PORT = process.env.PANEL_PORT || 3000;
const SECRET = process.env.PANEL_SECRET || 'xavibot_secret';

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../../panel/public')));
app.use(session({ secret: SECRET, resave: false, saveUninitialized: false }));

// ─── ROUTES ───────────────────────────────────────────────────────────────
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../../panel/public/index.html'));
});

app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, '../../panel/public/dashboard.html'));
});

// API: Connect new number
app.post('/api/connect', async (req, res) => {
  const { phone, name } = req.body;
  if (!phone) return res.json({ success: false, message: 'Phone number required' });
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  if (cleanPhone.length < 10) return res.json({ success: false, message: 'Invalid phone number' });
  try {
    const result = await createSession(cleanPhone, name || 'XaviBot User');
    res.json(result);
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});

// API: Get all sessions
app.get('/api/sessions', (req, res) => {
  const sessions = Sessions.getAll.all();
  const active = getActiveSessions();
  const result = sessions.map(s => ({
    ...s,
    isConnected: active.has(s.id),
    pairing_code: s.pairing_code,
  }));
  res.json(result);
});

// API: Delete session
app.delete('/api/sessions/:id', async (req, res) => {
  try {
    const result = await deleteSession(req.params.id);
    res.json(result);
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});

// API: Get stats
app.get('/api/stats', (req, res) => {
  const allSessions = Sessions.getAll.all();
  const activeSessions = Sessions.countActive.get();
  const mem = process.memoryUsage();
  res.json({
    totalSessions: allSessions.length,
    activeSessions: activeSessions?.count || 0,
    uptime: Math.floor(process.uptime()),
    memoryMB: Math.round(mem.rss / 1024 / 1024),
    botName: process.env.BOT_NAME || 'XaviBot',
  });
});

// Socket.IO
io.on('connection', (socket) => {
  console.log('Panel client connected');
  // Send current sessions on connect
  const sessions = Sessions.getAll.all();
  socket.emit('initial_sessions', sessions);
});

function startPanel(sessionManager) {
  setSocketIO(io);
  httpServer.listen(PORT, () => {
    console.log(`\n╔══════════════════════════════════╗`);
    console.log(`║  🤖 XaviBot Panel is LIVE!       ║`);
    console.log(`║  🌐 http://localhost:${PORT}         ║`);
    console.log(`╚══════════════════════════════════╝\n`);
  });
}

module.exports = { startPanel, io };
