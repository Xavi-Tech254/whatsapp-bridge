const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DB_PATH = process.env.DB_PATH || './data/xavibot.db';
const dir = path.dirname(DB_PATH);
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      phone TEXT UNIQUE NOT NULL,
      name TEXT,
      status TEXT DEFAULT 'pending',
      pairing_code TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
      message_count INTEGER DEFAULT 0,
      is_active INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      jid TEXT NOT NULL,
      session_id TEXT NOT NULL,
      name TEXT,
      is_banned INTEGER DEFAULT 0,
      is_premium INTEGER DEFAULT 0,
      warnings INTEGER DEFAULT 0,
      message_count INTEGER DEFAULT 0,
      xp INTEGER DEFAULT 0,
      level INTEGER DEFAULT 1,
      coins INTEGER DEFAULT 0,
      joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(jid, session_id)
    );

    CREATE TABLE IF NOT EXISTS groups (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      jid TEXT NOT NULL,
      session_id TEXT NOT NULL,
      name TEXT,
      is_welcome_on INTEGER DEFAULT 1,
      is_goodbye_on INTEGER DEFAULT 1,
      is_antilink INTEGER DEFAULT 0,
      is_antispam INTEGER DEFAULT 0,
      is_nsfw INTEGER DEFAULT 0,
      is_locked INTEGER DEFAULT 0,
      is_antitoxic INTEGER DEFAULT 0,
      welcome_msg TEXT DEFAULT 'Welcome {user} to {group}! 👋',
      goodbye_msg TEXT DEFAULT 'Goodbye {user}! We will miss you 👋',
      UNIQUE(jid, session_id)
    );

    CREATE TABLE IF NOT EXISTS notes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT NOT NULL,
      group_jid TEXT,
      name TEXT NOT NULL,
      content TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS banned_words (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT NOT NULL,
      group_jid TEXT,
      word TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS afk (
      jid TEXT NOT NULL,
      session_id TEXT NOT NULL,
      reason TEXT DEFAULT 'AFK',
      since DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY(jid, session_id)
    );

    CREATE TABLE IF NOT EXISTS reminders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT NOT NULL,
      jid TEXT NOT NULL,
      chat TEXT NOT NULL,
      message TEXT NOT NULL,
      remind_at DATETIME NOT NULL,
      is_done INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS polls (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT NOT NULL,
      group_jid TEXT NOT NULL,
      question TEXT NOT NULL,
      options TEXT NOT NULL,
      votes TEXT DEFAULT '{}',
      created_by TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      is_active INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT NOT NULL,
      session_id TEXT NOT NULL,
      value TEXT,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY(key, session_id)
    );

    CREATE TABLE IF NOT EXISTS command_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT NOT NULL,
      jid TEXT,
      chat TEXT,
      command TEXT,
      args TEXT,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS economy (
      jid TEXT NOT NULL,
      session_id TEXT NOT NULL,
      coins INTEGER DEFAULT 100,
      bank INTEGER DEFAULT 0,
      last_daily DATETIME,
      last_work DATETIME,
      last_crime DATETIME,
      streak INTEGER DEFAULT 0,
      PRIMARY KEY(jid, session_id)
    );

    CREATE TABLE IF NOT EXISTS marriage (
      jid TEXT NOT NULL,
      session_id TEXT NOT NULL,
      partner TEXT,
      married_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY(jid, session_id)
    );

    CREATE TABLE IF NOT EXISTS todos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      jid TEXT NOT NULL,
      session_id TEXT NOT NULL,
      task TEXT NOT NULL,
      is_done INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS broadcasts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT NOT NULL,
      message TEXT NOT NULL,
      targets TEXT NOT NULL,
      sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      status TEXT DEFAULT 'sent'
    );
  `);

  console.log('✅ XaviBot Database initialized');
}

const Sessions = {
  create: db.prepare('INSERT OR IGNORE INTO sessions (id, phone, name, status) VALUES (?, ?, ?, ?)'),
  getByPhone: db.prepare('SELECT * FROM sessions WHERE phone = ?'),
  getById: db.prepare('SELECT * FROM sessions WHERE id = ?'),
  updateStatus: db.prepare('UPDATE sessions SET status = ?, last_seen = CURRENT_TIMESTAMP WHERE id = ?'),
  updatePairingCode: db.prepare('UPDATE sessions SET pairing_code = ? WHERE id = ?'),
  setActive: db.prepare('UPDATE sessions SET is_active = ? WHERE id = ?'),
  incMessages: db.prepare('UPDATE sessions SET message_count = message_count + 1, last_seen = CURRENT_TIMESTAMP WHERE id = ?'),
  getAll: db.prepare('SELECT * FROM sessions ORDER BY created_at DESC'),
  getActive: db.prepare('SELECT * FROM sessions WHERE is_active = 1'),
  delete: db.prepare('DELETE FROM sessions WHERE id = ?'),
  count: db.prepare('SELECT COUNT(*) as count FROM sessions'),
  countActive: db.prepare('SELECT COUNT(*) as count FROM sessions WHERE is_active = 1'),
};

const Users = {
  upsert: db.prepare('INSERT OR IGNORE INTO users (jid, session_id, name) VALUES (?, ?, ?)'),
  get: db.prepare('SELECT * FROM users WHERE jid = ? AND session_id = ?'),
  ban: db.prepare('UPDATE users SET is_banned = 1 WHERE jid = ? AND session_id = ?'),
  unban: db.prepare('UPDATE users SET is_banned = 0 WHERE jid = ? AND session_id = ?'),
  setPremium: db.prepare('UPDATE users SET is_premium = ? WHERE jid = ? AND session_id = ?'),
  addWarning: db.prepare('UPDATE users SET warnings = warnings + 1 WHERE jid = ? AND session_id = ?'),
  resetWarnings: db.prepare('UPDATE users SET warnings = 0 WHERE jid = ? AND session_id = ?'),
  incMessages: db.prepare('UPDATE users SET message_count = message_count + 1 WHERE jid = ? AND session_id = ?'),
  addXp: db.prepare('UPDATE users SET xp = xp + ? WHERE jid = ? AND session_id = ?'),
  setLevel: db.prepare('UPDATE users SET level = ? WHERE jid = ? AND session_id = ?'),
  getBanned: db.prepare('SELECT * FROM users WHERE session_id = ? AND is_banned = 1'),
  getTop: db.prepare('SELECT * FROM users WHERE session_id = ? ORDER BY xp DESC LIMIT 10'),
};

const Groups = {
  upsert: db.prepare('INSERT OR IGNORE INTO groups (jid, session_id, name) VALUES (?, ?, ?)'),
  get: db.prepare('SELECT * FROM groups WHERE jid = ? AND session_id = ?'),
  setWelcome: db.prepare('UPDATE groups SET is_welcome_on = ?, welcome_msg = ? WHERE jid = ? AND session_id = ?'),
  setGoodbye: db.prepare('UPDATE groups SET is_goodbye_on = ?, goodbye_msg = ? WHERE jid = ? AND session_id = ?'),
  setAntilink: db.prepare('UPDATE groups SET is_antilink = ? WHERE jid = ? AND session_id = ?'),
  setAntispam: db.prepare('UPDATE groups SET is_antispam = ? WHERE jid = ? AND session_id = ?'),
  setNsfw: db.prepare('UPDATE groups SET is_nsfw = ? WHERE jid = ? AND session_id = ?'),
  setLocked: db.prepare('UPDATE groups SET is_locked = ? WHERE jid = ? AND session_id = ?'),
  setAntitoxic: db.prepare('UPDATE groups SET is_antitoxic = ? WHERE jid = ? AND session_id = ?'),
};

const Notes = {
  set: db.prepare('INSERT OR REPLACE INTO notes (session_id, group_jid, name, content) VALUES (?, ?, ?, ?)'),
  get: db.prepare('SELECT * FROM notes WHERE session_id = ? AND name = ? AND group_jid = ?'),
  getAll: db.prepare('SELECT * FROM notes WHERE session_id = ? AND group_jid = ?'),
  delete: db.prepare('DELETE FROM notes WHERE session_id = ? AND name = ? AND group_jid = ?'),
};

const Afk = {
  set: db.prepare('INSERT OR REPLACE INTO afk (jid, session_id, reason) VALUES (?, ?, ?)'),
  get: db.prepare('SELECT * FROM afk WHERE jid = ? AND session_id = ?'),
  delete: db.prepare('DELETE FROM afk WHERE jid = ? AND session_id = ?'),
};

const Settings = {
  get: db.prepare('SELECT value FROM settings WHERE key = ? AND session_id = ?'),
  set: db.prepare('INSERT OR REPLACE INTO settings (key, session_id, value, updated_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP)'),
};

const Logs = {
  add: db.prepare('INSERT INTO command_logs (session_id, jid, chat, command, args) VALUES (?, ?, ?, ?, ?)'),
  getRecent: db.prepare('SELECT * FROM command_logs WHERE session_id = ? ORDER BY timestamp DESC LIMIT 50'),
  getStats: db.prepare('SELECT command, COUNT(*) as count FROM command_logs WHERE session_id = ? GROUP BY command ORDER BY count DESC LIMIT 10'),
  totalCount: db.prepare('SELECT COUNT(*) as count FROM command_logs WHERE session_id = ?'),
};

const Economy = {
  init: db.prepare('INSERT OR IGNORE INTO economy (jid, session_id) VALUES (?, ?)'),
  get: db.prepare('SELECT * FROM economy WHERE jid = ? AND session_id = ?'),
  addCoins: db.prepare('UPDATE economy SET coins = coins + ? WHERE jid = ? AND session_id = ?'),
  removeCoins: db.prepare('UPDATE economy SET coins = MAX(0, coins - ?) WHERE jid = ? AND session_id = ?'),
  deposit: db.prepare('UPDATE economy SET coins = coins - ?, bank = bank + ? WHERE jid = ? AND session_id = ?'),
  withdraw: db.prepare('UPDATE economy SET bank = bank - ?, coins = coins + ? WHERE jid = ? AND session_id = ?'),
  setDaily: db.prepare('UPDATE economy SET last_daily = CURRENT_TIMESTAMP, streak = streak + 1 WHERE jid = ? AND session_id = ?'),
  setWork: db.prepare('UPDATE economy SET last_work = CURRENT_TIMESTAMP WHERE jid = ? AND session_id = ?'),
  setCrime: db.prepare('UPDATE economy SET last_crime = CURRENT_TIMESTAMP WHERE jid = ? AND session_id = ?'),
  getTop: db.prepare('SELECT * FROM economy WHERE session_id = ? ORDER BY coins + bank DESC LIMIT 10'),
};

const Marriage = {
  get: db.prepare('SELECT * FROM marriage WHERE jid = ? AND session_id = ?'),
  set: db.prepare('INSERT OR REPLACE INTO marriage (jid, session_id, partner) VALUES (?, ?, ?)'),
  delete: db.prepare('DELETE FROM marriage WHERE jid = ? AND session_id = ?'),
};

const Polls = {
  create: db.prepare('INSERT INTO polls (session_id, group_jid, question, options, created_by) VALUES (?, ?, ?, ?, ?)'),
  get: db.prepare('SELECT * FROM polls WHERE id = ?'),
  getActive: db.prepare('SELECT * FROM polls WHERE group_jid = ? AND session_id = ? AND is_active = 1 ORDER BY created_at DESC LIMIT 1'),
  updateVotes: db.prepare('UPDATE polls SET votes = ? WHERE id = ?'),
  end: db.prepare('UPDATE polls SET is_active = 0 WHERE id = ?'),
};

const Todos = {
  add: db.prepare('INSERT INTO todos (jid, session_id, task) VALUES (?, ?, ?)'),
  getAll: db.prepare('SELECT * FROM todos WHERE jid = ? AND session_id = ? AND is_done = 0'),
  done: db.prepare('UPDATE todos SET is_done = 1 WHERE id = ? AND jid = ?'),
  delete: db.prepare('DELETE FROM todos WHERE id = ? AND jid = ?'),
  clear: db.prepare('DELETE FROM todos WHERE jid = ? AND session_id = ?'),
};

const Reminders = {
  add: db.prepare('INSERT INTO reminders (session_id, jid, chat, message, remind_at) VALUES (?, ?, ?, ?, ?)'),
  getPending: db.prepare('SELECT * FROM reminders WHERE session_id = ? AND is_done = 0 AND remind_at <= datetime("now")'),
  markDone: db.prepare('UPDATE reminders SET is_done = 1 WHERE id = ?'),
  getUserReminders: db.prepare('SELECT * FROM reminders WHERE jid = ? AND session_id = ? AND is_done = 0'),
};

module.exports = {
  db,
  initDatabase,
  Sessions,
  Users,
  Groups,
  Notes,
  Afk,
  Settings,
  Logs,
  Economy,
  Marriage,
  Polls,
  Todos,
  Reminders,
};
