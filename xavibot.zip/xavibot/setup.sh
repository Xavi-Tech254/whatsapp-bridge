#!/bin/bash
echo "🤖 XaviBot Setup Script"
echo "========================"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Copy .env if not exists
if [ ! -f .env ]; then
  cp .env.example .env
  echo "✅ Created .env file — edit it with your settings!"
fi

mkdir -p sessions data logs temp

echo ""
echo "✅ Setup complete!"
echo ""
echo "👉 Next steps:"
echo "  1. Edit .env with your OWNER_NUMBER and optional API keys"
echo "  2. Run: npm start"
echo "  3. Open: http://localhost:3000"
echo "  4. Enter your WhatsApp number to get a pairing code"
echo ""
echo "🚀 XaviBot is ready!"
